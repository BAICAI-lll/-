-- 添加学生-课程关联表
USE exam_system;

-- 1. 创建student_courses表
CREATE TABLE IF NOT EXISTS student_courses (
    student_id VARCHAR(10) NOT NULL,
    course_id VARCHAR(10) NOT NULL,
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. 为现有学生添加初始课程数据
INSERT INTO student_courses VALUES
('student001', 'course001'),
('student001', 'course002'),
('student002', 'course001'),
('student002', 'course002');

-- 3. 查看添加的数据
SELECT * FROM student_courses;
