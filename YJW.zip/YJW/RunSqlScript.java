import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import com.exam.util.DBUtil;

public class RunSqlScript {
    public static void main(String[] args) {
        // 读取并执行SQL脚本
        String scriptPath = "add_student_courses_table.sql";
        System.out.println("执行SQL脚本: " + scriptPath);
        
        try (BufferedReader reader = new BufferedReader(new FileReader(scriptPath));
             Connection conn = DBUtil.getStaticConnection()) {
            
            System.out.println("数据库连接: " + (conn != null ? "成功" : "失败"));
            
            if (conn != null) {
                try (Statement stmt = conn.createStatement()) {
                    StringBuilder sqlBuilder = new StringBuilder();
                    String line;
                    
                    // 读取SQL脚本文件
                    while ((line = reader.readLine()) != null) {
                        // 跳过注释和空行
                        if (line.trim().startsWith("--") || line.trim().isEmpty()) {
                            continue;
                        }
                        
                        sqlBuilder.append(line);
                        
                        // 如果当前行以分号结束，执行SQL语句
                        if (line.trim().endsWith(";")) {
                            String sql = sqlBuilder.toString();
                            System.out.println("执行SQL: " + sql);
                            stmt.executeUpdate(sql);
                            sqlBuilder.setLength(0);
                        }
                    }
                    
                    System.out.println("SQL脚本执行完成");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}