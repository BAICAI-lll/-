-- 更新scores表结构，添加缺少的字段
USE exam_system;

-- 1. 添加exam_status字段
ALTER TABLE scores 
ADD COLUMN exam_status VARCHAR(20) DEFAULT 'not_started' AFTER score;

-- 2. 添加exam_count字段
ALTER TABLE scores 
ADD COLUMN exam_count INT DEFAULT 0 AFTER exam_status;

-- 3. 查看更新后的表结构
DESCRIBE scores;

-- 4. 更新现有数据的exam_status字段
UPDATE scores SET 
    exam_status = 'completed';

-- 5. 更新现有数据的exam_count字段
UPDATE scores SET 
    exam_count = 1;

-- 6. 查看更新后的数据
SELECT * FROM scores;
