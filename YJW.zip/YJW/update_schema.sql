`users`-- 修改scores表，添加考试状态和考试次数字段
ALTER TABLE scores ADD COLUMN exam_status VARCHAR(20) NOT NULL DEFAULT 'pending';
ALTER TABLE scores ADD COLUMN exam_count INT NOT NULL DEFAULT 1;

-- 更新现有记录的状态为pending
UPDATE scores SET exam_status = 'pending';
