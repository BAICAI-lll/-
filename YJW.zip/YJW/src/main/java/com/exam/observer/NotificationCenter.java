package com.exam.observer;

import java.util.ArrayList;
import java.util.List;

// 系统通知中心 - 具体主题
public class NotificationCenter implements Subject {
    private List<Observer> observers = new ArrayList<>();
    private static volatile NotificationCenter instance;
    
    // 单例模式实现
    private NotificationCenter() {}
    
    public static NotificationCenter getInstance() {
        if (instance == null) {
            synchronized (NotificationCenter.class) {
                if (instance == null) {
                    instance = new NotificationCenter();
                }
            }
        }
        return instance;
    }
    
    @Override
    public void registerObserver(Observer observer) {
        if (!observers.contains(observer)) {
            observers.add(observer);
        }
    }
    
    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }
    
    @Override
    public void notifyObservers(String message) {
        for (Observer observer : observers) {
            observer.update(message);
        }
    }
    
    // 发送系统通知的便捷方法
    public static void sendNotification(String message) {
        getInstance().notifyObservers(message);
    }
}