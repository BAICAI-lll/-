package com.exam.observer;

import com.exam.util.LoggerManager;

// 日志观察者 - 具体观察者
public class LogObserver implements Observer {
    @Override
    public void update(String message) {
        LoggerManager.log("System Notification: " + message);
    }
}