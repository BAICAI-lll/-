package com.exam.observer;

// 观察者接口 - 行为型模式（观察者模式）
public interface Observer {
    void update(String message);
}