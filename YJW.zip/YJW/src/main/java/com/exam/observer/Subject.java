package com.exam.observer;

// 主题接口 - 行为型模式（观察者模式）
public interface Subject {
    void registerObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers(String message);
}