package com.exam.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.exam.model.Teacher;
import com.exam.model.Student;
import com.exam.model.Course;
import com.exam.model.ClassInfo;
import com.exam.service.TeacherService;
import com.exam.service.StudentService;
import com.exam.service.CourseService;
import com.exam.service.ClassService;
import com.exam.service.ScoreService;
import com.exam.service.UserService;

public class AdminServlet extends HttpServlet {
    private TeacherService teacherService = new TeacherService();
    private StudentService studentService = new StudentService();
    private CourseService courseService = new CourseService();
    private ClassService classService = new ClassService();
    private ScoreService scoreService = new ScoreService();
    private UserService userService = new UserService();
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null) action = "";
        
        switch (action) {
            // 用户管理
            case "addUser":
                addUser(req, resp);
                break;
            case "deleteUser":
                deleteUser(req, resp);
                break;
            case "updateUser":
                updateUser(req, resp);
                break;
            case "listUsers":
                listUsers(req, resp);
                break;
                
            // 教师管理
            case "addTeacher":
                addTeacher(req, resp);
                break;
            case "deleteTeacher":
                deleteTeacher(req, resp);
                break;
            case "updateTeacher":
                updateTeacher(req, resp);
                break;
            case "listTeachers":
                listTeachers(req, resp);
                break;
                
            // 学生管理
            case "addStudent":
                addStudent(req, resp);
                break;
            case "deleteStudent":
                deleteStudent(req, resp);
                break;
            case "updateStudent":
                updateStudent(req, resp);
                break;
            case "listStudents":
                listStudents(req, resp);
                break;
                
            // 课程管理
            case "addCourse":
                addCourse(req, resp);
                break;
            case "deleteCourse":
                deleteCourse(req, resp);
                break;
            case "updateCourse":
                updateCourse(req, resp);
                break;
            case "listCourses":
                listCourses(req, resp);
                break;
                
            // 班级管理
            case "addClass":
                addClass(req, resp);
                break;
            case "deleteClass":
                deleteClass(req, resp);
                break;
            case "updateClass":
                updateClass(req, resp);
                break;
            case "listClasses":
                listClasses(req, resp);
                break;
                
            // 成绩查询
            case "queryScores":
                queryScores(req, resp);
                break;
                
            // 成绩详情
            case "scoreDetail":
                scoreDetail(req, resp);
                break;
                
            // 修改密码
            case "changePassword":
                changePassword(req, resp);
                break;
                
            default:
                resp.sendRedirect(req.getContextPath() + "/admin/index.jsp");
        }
    }
    
    // 教师管理方法
    private void addTeacher(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String teacherId = req.getParameter("teacherId");
        String name = req.getParameter("name");
        String gender = req.getParameter("gender");
        String phone = req.getParameter("phone");
        
        Teacher teacher = new Teacher();
        teacher.setTeacherId(teacherId);
        teacher.setName(name);
        teacher.setGender(gender);
        teacher.setPhone(phone);
        
        teacherService.addTeacher(teacher);
        resp.sendRedirect(req.getContextPath() + "/api/admin?action=listTeachers");
    }
    
    private void deleteTeacher(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String teacherId = req.getParameter("teacherId");
        teacherService.deleteTeacher(teacherId);
        resp.sendRedirect(req.getContextPath() + "/api/admin?action=listTeachers");
    }
    
    private void updateTeacher(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String teacherId = req.getParameter("teacherId");
        String name = req.getParameter("name");
        String gender = req.getParameter("gender");
        String phone = req.getParameter("phone");
        
        // 检查是否是编辑页面请求（只有teacherId参数）
        if (name == null || gender == null || phone == null) {
            // 跳转到编辑页面
            Teacher teacher = teacherService.getTeacherById(teacherId);
            req.setAttribute("teacher", teacher);
            req.getRequestDispatcher("/admin/editTeacher.jsp").forward(req, resp);
        } else {
            // 执行更新操作
            Teacher teacher = new Teacher();
            teacher.setTeacherId(teacherId);
            teacher.setName(name);
            teacher.setGender(gender);
            teacher.setPhone(phone);
            
            teacherService.updateTeacher(teacher);
            resp.sendRedirect(req.getContextPath() + "/api/admin?action=listTeachers");
        }
    }
    
    private void listTeachers(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Teacher> teachers = teacherService.getAllTeachers();
        req.setAttribute("teachers", teachers);
        req.getRequestDispatcher("/admin/teachers.jsp").forward(req, resp);
    }
    
    // 学生管理方法
    private void addStudent(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String studentId = req.getParameter("studentId");
        String name = req.getParameter("name");
        String gender = req.getParameter("gender");
        String className = req.getParameter("className");
        
        Student student = new Student();
        student.setStudentId(studentId);
        student.setName(name);
        student.setGender(gender);
        student.setClassName(className);
        
        // 添加学生信息
        studentService.addStudent(student);
        
        // 自动创建对应的用户账号
        // 从studentId中提取数字部分，例如从"student001"中提取"1"
        String numStr = studentId.replaceAll("[^0-9]", "");
        int num = Integer.parseInt(numStr);
        String username = "student" + num;
        String password = "123456";
        String role = "student";
        
        // 创建用户对象
        com.exam.model.User user = new com.exam.model.User(username, password, role);
        // 添加用户账号
        userService.addUser(user);
        
        resp.sendRedirect(req.getContextPath() + "/api/admin?action=listStudents");
    }
    
    private void deleteStudent(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String studentId = req.getParameter("studentId");
        studentService.deleteStudent(studentId);
        resp.sendRedirect(req.getContextPath() + "/api/admin?action=listStudents");
    }
    
    private void updateStudent(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String studentId = req.getParameter("studentId");
        String name = req.getParameter("name");
        String gender = req.getParameter("gender");
        String className = req.getParameter("className");
        
        // 检查是否是编辑页面请求（只有studentId参数）
        if (name == null || gender == null || className == null) {
            // 跳转到编辑页面
            Student student = studentService.getStudentById(studentId);
            req.setAttribute("student", student);
            req.getRequestDispatcher("/admin/editStudent.jsp").forward(req, resp);
        } else {
            // 执行更新操作
            Student student = new Student();
            student.setStudentId(studentId);
            student.setName(name);
            student.setGender(gender);
            student.setClassName(className);
            
            studentService.updateStudent(student);
            resp.sendRedirect(req.getContextPath() + "/api/admin?action=listStudents");
        }
    }
    
    private void listStudents(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Student> students = studentService.getAllStudents();
        req.setAttribute("students", students);
        req.getRequestDispatcher("/admin/students.jsp").forward(req, resp);
    }
    
    // 课程管理方法
    private void addCourse(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String courseId = req.getParameter("courseId");
        String courseName = req.getParameter("courseName");
        String teacherId = req.getParameter("teacherId");
        
        Course course = new Course();
        course.setCourseId(courseId);
        course.setCourseName(courseName);
        course.setTeacherId(teacherId);
        
        courseService.addCourse(course);
        resp.sendRedirect(req.getContextPath() + "/api/admin?action=listCourses");
    }
    
    private void deleteCourse(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String courseId = req.getParameter("courseId");
        courseService.deleteCourse(courseId);
        resp.sendRedirect(req.getContextPath() + "/api/admin?action=listCourses");
    }
    
    private void updateCourse(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String courseId = req.getParameter("courseId");
        String courseName = req.getParameter("courseName");
        String teacherId = req.getParameter("teacherId");
        
        // 检查是否是编辑页面请求（只有courseId参数）
        if (courseName == null || teacherId == null) {
            // 跳转到编辑页面
            Course course = courseService.getCourseById(courseId);
            req.setAttribute("course", course);
            req.getRequestDispatcher("/admin/editCourse.jsp").forward(req, resp);
        } else {
            // 执行更新操作
            Course course = new Course();
            course.setCourseId(courseId);
            course.setCourseName(courseName);
            course.setTeacherId(teacherId);
            
            courseService.updateCourse(course);
            resp.sendRedirect(req.getContextPath() + "/api/admin?action=listCourses");
        }
    }
    
    private void listCourses(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Course> courses = courseService.getAllCourses();
        req.setAttribute("courses", courses);
        req.getRequestDispatcher("/admin/courses.jsp").forward(req, resp);
    }
    
    // 班级管理方法
    private void addClass(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String classId = req.getParameter("classId");
        String className = req.getParameter("className");
        
        ClassInfo classInfo = new ClassInfo();
        classInfo.setClassId(classId);
        classInfo.setClassName(className);
        
        classService.addClass(classInfo);
        resp.sendRedirect(req.getContextPath() + "/api/admin?action=listClasses");
    }
    
    private void deleteClass(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String classId = req.getParameter("classId");
        classService.deleteClass(classId);
        resp.sendRedirect(req.getContextPath() + "/api/admin?action=listClasses");
    }
    
    private void updateClass(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String classId = req.getParameter("classId");
        String className = req.getParameter("className");
        
        // 检查是否是编辑页面请求（只有classId参数）
        if (className == null) {
            // 跳转到编辑页面
            ClassInfo classInfo = classService.getClassById(classId);
            req.setAttribute("classInfo", classInfo);
            req.getRequestDispatcher("/admin/editClass.jsp").forward(req, resp);
        } else {
            // 执行更新操作
            ClassInfo classInfo = new ClassInfo();
            classInfo.setClassId(classId);
            classInfo.setClassName(className);
            
            classService.updateClass(classInfo);
            resp.sendRedirect(req.getContextPath() + "/api/admin?action=listClasses");
        }
    }
    
    private void listClasses(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<ClassInfo> classes = classService.getAllClasses();
        req.setAttribute("classes", classes);
        req.getRequestDispatcher("/admin/classes.jsp").forward(req, resp);
    }
    
    // 成绩查询方法
    private void queryScores(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<com.exam.model.Score> scores = scoreService.getAllScores();
        req.setAttribute("scores", scores);
        req.getRequestDispatcher("/admin/scores.jsp").forward(req, resp);
    }
    
    // 成绩详情方法
    private void scoreDetail(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String studentId = req.getParameter("studentId");
        String courseId = req.getParameter("courseId");
        
        // 这里简化处理，实际应该根据studentId和courseId查询具体成绩
        // 这里直接使用所有成绩中的第一个成绩
        List<com.exam.model.Score> scores = scoreService.getAllScores();
        com.exam.model.Score score = null;
        for (com.exam.model.Score s : scores) {
            if (s.getStudentId().equals(studentId) && s.getCourseId().equals(courseId)) {
                score = s;
                break;
            }
        }
        
        req.setAttribute("score", score);
        req.getRequestDispatcher("/admin/scoreDetail.jsp").forward(req, resp);
    }
    
    // 用户管理方法
    private void addUser(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String role = req.getParameter("role");
        String userId = req.getParameter("user_id");
        String classCourseId = req.getParameter("class_course_id");
        
        // 创建包含userId和classCourseId的User对象
        com.exam.model.User user = new com.exam.model.User(username, password, role, userId, classCourseId);
        userService.addUser(user);
        resp.sendRedirect(req.getContextPath() + "/api/admin?action=listUsers");
    }
    
    private void deleteUser(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        userService.deleteUser(username);
        resp.sendRedirect(req.getContextPath() + "/api/admin?action=listUsers");
    }
    
    private void updateUser(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String role = req.getParameter("role");
        String userId = req.getParameter("user_id");
        String classCourseId = req.getParameter("class_course_id");
        
        // 创建包含userId和classCourseId的User对象
        com.exam.model.User user = new com.exam.model.User(username, password, role, userId, classCourseId);
        userService.updateUser(user);
        resp.sendRedirect(req.getContextPath() + "/api/admin?action=listUsers");
    }
    
    private void listUsers(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<com.exam.model.User> users = userService.getAllUsers();
        req.setAttribute("users", users);
        req.getRequestDispatcher("/admin/users.jsp").forward(req, resp);
    }
    
    // 修改密码方法
    private void changePassword(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 实现修改密码逻辑
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}