package com.exam.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.exam.model.User;
import com.exam.service.UserService;

public class LoginServlet extends HttpServlet {
    private UserService userService = new UserService();
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String role = req.getParameter("role");
        
        User user = userService.login(username, password, role);
        if (user != null) {
            HttpSession session = req.getSession();
            // 使用数据库返回的英文角色值
            String actualRole = user.getRole();
            session.setAttribute("user", user);
            session.setAttribute("username", username);
            session.setAttribute("role", actualRole);
            
            // 根据角色跳转到不同页面
            String contextPath = req.getContextPath();
            switch (actualRole) {
                case "admin":
                    resp.sendRedirect(contextPath + "/admin/index.jsp");
                    break;
                case "teacher":
                    resp.sendRedirect(contextPath + "/teacher/index.jsp");
                    break;
                case "student":
                    resp.sendRedirect(contextPath + "/student/index.jsp");
                    break;
                default:
                    resp.sendRedirect(contextPath + "/index.jsp");
            }
        } else {
            req.setAttribute("error", "用户名、密码或角色错误");
            String contextPath = req.getContextPath();
            req.getRequestDispatcher("/index.jsp").forward(req, resp);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}