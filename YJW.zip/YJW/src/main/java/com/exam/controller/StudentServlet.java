package com.exam.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.exam.model.Course;
import com.exam.model.Question;
import com.exam.service.CourseService;
import com.exam.service.QuestionService;
import com.exam.service.ScoreService;
import com.exam.service.StudentCourseService;
import com.exam.service.UserService;

public class StudentServlet extends HttpServlet {
    private CourseService courseService = new CourseService();
    private QuestionService questionService = new QuestionService();
    private ScoreService scoreService = new ScoreService();
    private StudentCourseService studentCourseService = new StudentCourseService();
    private UserService userService = new UserService();
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null) action = "";
        
        switch (action) {
            // 课程选择
            case "selectCourse":
                selectCourse(req, resp);
                break;
            case "listCourses":
                listCourses(req, resp);
                break;
            case "viewAvailableCourses":
                viewAvailableCourses(req, resp);
                break;
            case "cancelCourse":
                cancelCourse(req, resp);
                break;
                
            // 答题操作
            case "startExam":
                startExam(req, resp);
                break;
            case "submitExam":
                submitExam(req, resp);
                break;
                
            // 成绩查询
            case "queryScores":
                queryScores(req, resp);
                break;
                
            // 修改密码
            case "changePassword":
                changePassword(req, resp);
                break;
                
            default:
                resp.sendRedirect(req.getContextPath() + "/student/index.jsp");
        }
    }
    
    // 查看已选课程
    private void listCourses(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 从session中获取当前登录的用户对象
        javax.servlet.http.HttpSession session = req.getSession();
        com.exam.model.User user = (com.exam.model.User) session.getAttribute("user");
        
        // 使用用户对象的userId属性作为学生ID
        String studentId = user.getUserId();
        
        // 获取学生已选择的课程
        List<Course> courses = studentCourseService.getCoursesByStudentId(studentId);
        
        // 创建一个Map来存储每个课程的考试状态
        java.util.Map<String, com.exam.model.Score> courseScores = new java.util.HashMap<>();
        
        for (Course course : courses) {
            com.exam.model.Score score = scoreService.getScoreByStudentAndCourse(studentId, course.getCourseId());
            if (score != null) {
                courseScores.put(course.getCourseId(), score);
            }
        }
        
        req.setAttribute("courses", courses);
        req.setAttribute("courseScores", courseScores);
        req.getRequestDispatcher("/student/courses.jsp").forward(req, resp);
    }
    
    // 查看可选课程
    private void viewAvailableCourses(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 从session中获取当前登录的用户对象
        javax.servlet.http.HttpSession session = req.getSession();
        com.exam.model.User user = (com.exam.model.User) session.getAttribute("user");
        
        // 使用用户对象的userId属性作为学生ID
        String studentId = user.getUserId();
        
        // 获取学生未选择的课程
        List<Course> availableCourses = studentCourseService.getAvailableCourses(studentId);
        
        req.setAttribute("availableCourses", availableCourses);
        req.getRequestDispatcher("/student/availableCourses.jsp").forward(req, resp);
    }
    
    // 学生选择课程
    private void selectCourse(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 从session中获取当前登录的用户对象
        javax.servlet.http.HttpSession session = req.getSession();
        com.exam.model.User user = (com.exam.model.User) session.getAttribute("user");
        
        // 使用用户对象的userId属性作为学生ID
        String studentId = user.getUserId();
        
        // 获取课程ID
        String courseId = req.getParameter("courseId");
        
        // 选择课程
        boolean result = studentCourseService.addStudentCourse(studentId, courseId);
        
        // 重定向回课程列表
        resp.sendRedirect(req.getContextPath() + "/api/student?action=listCourses");
    }
    
    // 学生取消选择课程
    private void cancelCourse(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 从session中获取当前登录的用户对象
        javax.servlet.http.HttpSession session = req.getSession();
        com.exam.model.User user = (com.exam.model.User) session.getAttribute("user");
        
        // 使用用户对象的userId属性作为学生ID
        String studentId = user.getUserId();
        
        // 获取课程ID
        String courseId = req.getParameter("courseId");
        
        // 取消选择课程
        boolean result = studentCourseService.deleteStudentCourse(studentId, courseId);
        
        // 重定向回课程列表
        resp.sendRedirect(req.getContextPath() + "/api/student?action=listCourses");
    }
    
    // 答题操作方法
    private void startExam(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String courseId = req.getParameter("courseId");
        // 从session中获取当前登录的用户对象
        javax.servlet.http.HttpSession session = req.getSession();
        com.exam.model.User user = (com.exam.model.User) session.getAttribute("user");
        
        // 使用用户对象的userId属性作为学生ID
        String studentId = user.getUserId();
        
        // 检查学生是否已选择该课程
        boolean isSelected = studentCourseService.isCourseSelected(studentId, courseId);
        if (!isSelected) {
            req.setAttribute("error", "您还未选择该课程，无法参加考试！");
            listCourses(req, resp);
            return;
        }
        
        // 检查该课程的考试状态
        com.exam.model.Score score = scoreService.getScoreByStudentAndCourse(studentId, courseId);
        
        // 如果成绩存在，且状态为已合格，则不允许再次考试
        if (score != null && "passed".equals(score.getExamStatus())) {
            req.setAttribute("error", "该课程已通过，不能再次考试！");
            listCourses(req, resp);
            return;
        }
        
        // 如果成绩存在，且状态为已提交（未审核），则不允许再次考试
        if (score != null && "submitted".equals(score.getExamStatus())) {
            req.setAttribute("error", "考试已提交，正在等待教师审核！");
            listCourses(req, resp);
            return;
        }
        
        // 如果成绩存在，且状态不是需要重考，则不允许再次考试
        if (score != null && !"need_retake".equals(score.getExamStatus())) {
            req.setAttribute("error", "您已经参加过该课程考试，等待教师审核！");
            listCourses(req, resp);
            return;
        }
        
        // 获取题目列表
        List<Question> questions = questionService.getQuestionsByCourseId(courseId);
        req.setAttribute("questions", questions);
        req.setAttribute("courseId", courseId);
        req.getRequestDispatcher("/student/exam.jsp").forward(req, resp);
    }
    
    private void submitExam(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 获取课程ID
        String courseId = req.getParameter("courseId");
        // 从session中获取当前登录的用户对象
        javax.servlet.http.HttpSession session = req.getSession();
        com.exam.model.User user = (com.exam.model.User) session.getAttribute("user");
        
        // 使用用户对象的userId属性作为学生ID
        String studentId = user.getUserId();
        
        // 获取所有题目
        List<Question> questions = questionService.getQuestionsByCourseId(courseId);
        
        // 计算成绩
        int totalQuestions = questions.size();
        int correctAnswers = 0;
        
        for (Question question : questions) {
            String questionId = String.valueOf(question.getQuestionId());
            String studentAnswer = req.getParameter("answer_" + questionId);
            String correctAnswer = question.getCorrectAnswer();
            
            // 如果学生回答了该题且答案正确
            if (studentAnswer != null && studentAnswer.equals(correctAnswer)) {
                correctAnswers++;
            }
        }
        
        // 计算得分（满分100分）
        double scoreValue = totalQuestions > 0 ? (correctAnswers * 100.0 / totalQuestions) : 0;
        
        // 检查成绩是否已存在
        com.exam.model.Score existingScore = scoreService.getScoreByStudentAndCourse(studentId, courseId);
        com.exam.model.Score scoreModel;
        
        if (existingScore != null) {
            // 已存在成绩，创建更新的成绩对象
            scoreModel = new com.exam.model.Score(studentId, courseId, scoreValue);
            // 设置考试状态为已提交
            scoreModel.setExamStatus("submitted");
            // 增加考试次数
            scoreModel.setExamCount(existingScore.getExamCount() + 1);
            // 更新成绩
            scoreService.updateScore(scoreModel);
        } else {
            // 不存在成绩，创建新的成绩对象
            scoreModel = new com.exam.model.Score(studentId, courseId, scoreValue);
            // 设置初始考试状态为已提交
            scoreModel.setExamStatus("submitted");
            // 设置初始考试次数为1
            scoreModel.setExamCount(1);
            // 添加成绩
            scoreService.addScore(scoreModel);
        }
        
        // 设置请求属性，用于结果页面显示
        req.setAttribute("score", scoreValue);
        req.setAttribute("totalQuestions", totalQuestions);
        req.setAttribute("correctAnswers", correctAnswers);
        req.setAttribute("questions", questions);
        req.setAttribute("studentId", studentId);
        req.setAttribute("courseId", courseId);
        
        // 跳转到考试结果页面
        req.getRequestDispatcher("/student/examResult.jsp").forward(req, resp);
    }
    
    // 成绩查询方法
    private void queryScores(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 从session中获取当前登录的用户对象
        javax.servlet.http.HttpSession session = req.getSession();
        com.exam.model.User user = (com.exam.model.User) session.getAttribute("user");
        
        // 使用用户对象的userId属性作为学生ID
        String studentId = user.getUserId();
        
        List<com.exam.model.Score> scores = scoreService.getScoresByStudentId(studentId);
        req.setAttribute("scores", scores);
        req.getRequestDispatcher("/student/scores.jsp").forward(req, resp);
    }
    
    // 修改密码方法
    private void changePassword(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 实现修改密码逻辑
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}