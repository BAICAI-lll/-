package com.exam.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.exam.model.Question;
import com.exam.model.Course;
import com.exam.service.QuestionService;
import com.exam.service.CourseService;
import com.exam.service.ScoreService;
import com.exam.service.UserService;

public class TeacherServlet extends HttpServlet {
    private QuestionService questionService = new QuestionService();
    private CourseService courseService = new CourseService();
    private ScoreService scoreService = new ScoreService();
    private UserService userService = new UserService();
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null) action = "";
        
        switch (action) {
            // 题库管理
            case "addQuestion":
                addQuestion(req, resp);
                break;
            case "deleteQuestion":
                deleteQuestion(req, resp);
                break;
            case "updateQuestion":
                updateQuestion(req, resp);
                break;
            case "listQuestions":
                listQuestions(req, resp);
                break;
                
            // 成绩查询和处理
            case "queryScores":
                queryScores(req, resp);
                break;
            case "markPassed":
                markPassed(req, resp);
                break;
            case "markNeedRetake":
                markNeedRetake(req, resp);
                break;
                
            // 修改密码
            case "changePassword":
                changePassword(req, resp);
                break;
                
            default:
                resp.sendRedirect(req.getContextPath() + "/teacher/index.jsp");
        }
    }
    
    // 题库管理方法
    private void addQuestion(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 获取表单参数
        String courseId = req.getParameter("courseId");
        String questionContent = req.getParameter("questionContent");
        String optionA = req.getParameter("optionA");
        String optionB = req.getParameter("optionB");
        String optionC = req.getParameter("optionC");
        String optionD = req.getParameter("optionD");
        String correctAnswer = req.getParameter("correctAnswer");
        
        // 创建Question对象
        Question question = new Question();
        question.setCourseId(courseId);
        question.setQuestionContent(questionContent);
        question.setOptionA(optionA);
        question.setOptionB(optionB);
        question.setOptionC(optionC);
        question.setOptionD(optionD);
        question.setCorrectAnswer(correctAnswer);
        
        // 调用service层添加题目
        questionService.addQuestion(question);
        
        // 重定向回题目列表页面
        resp.sendRedirect(req.getContextPath() + "/api/teacher?action=listQuestions&courseId=" + courseId);
    }
    
    private void deleteQuestion(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 获取参数
        String questionIdStr = req.getParameter("questionId");
        String courseId = req.getParameter("courseId");
        
        // 将questionId转换为int类型
        int questionId = Integer.parseInt(questionIdStr);
        
        // 调用service层删除题目
        questionService.deleteQuestion(questionId);
        
        // 重定向回题目列表页面
        resp.sendRedirect(req.getContextPath() + "/api/teacher?action=listQuestions&courseId=" + courseId);
    }
    
    private void updateQuestion(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 获取表单参数
        String questionIdStr = req.getParameter("questionId");
        String courseId = req.getParameter("courseId");
        String questionContent = req.getParameter("questionContent");
        String optionA = req.getParameter("optionA");
        String optionB = req.getParameter("optionB");
        String optionC = req.getParameter("optionC");
        String optionD = req.getParameter("optionD");
        String correctAnswer = req.getParameter("correctAnswer");
        
        // 将questionId转换为int类型
        int questionId = Integer.parseInt(questionIdStr);
        
        // 创建Question对象
        Question question = new Question();
        question.setQuestionId(questionId);
        question.setCourseId(courseId);
        question.setQuestionContent(questionContent);
        question.setOptionA(optionA);
        question.setOptionB(optionB);
        question.setOptionC(optionC);
        question.setOptionD(optionD);
        question.setCorrectAnswer(correctAnswer);
        
        // 调用service层更新题目
        questionService.updateQuestion(question);
        
        // 重定向回题目列表页面
        resp.sendRedirect(req.getContextPath() + "/api/teacher?action=listQuestions&courseId=" + courseId);
    }
    
    private void listQuestions(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String courseId = req.getParameter("courseId");
        List<Question> questions;
        
        // 如果courseId为空或无效，返回所有题目
        if (courseId == null || courseId.isEmpty()) {
            questions = questionService.getAllQuestions();
        } else {
            questions = questionService.getQuestionsByCourseId(courseId);
        }
        
        req.setAttribute("questions", questions);
        req.setAttribute("courseId", courseId);
        req.getRequestDispatcher("/teacher/questions.jsp").forward(req, resp);
    }
    
    // 成绩查询方法
    private void queryScores(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 假设当前教师ID存储在session中，这里简化处理
        String teacherId = "1";
        List<com.exam.model.Score> scores = scoreService.getAllScores();
        req.setAttribute("scores", scores);
        req.getRequestDispatcher("/teacher/scores.jsp").forward(req, resp);
    }
    
    // 成绩处理方法
    private void markPassed(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String studentId = req.getParameter("studentId");
        String courseId = req.getParameter("courseId");
        
        // 更新成绩状态为已合格
        scoreService.updateScoreStatus(studentId, courseId, "passed");
        
        // 重定向回成绩列表
        resp.sendRedirect(req.getContextPath() + "/api/teacher?action=queryScores");
    }
    
    private void markNeedRetake(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String studentId = req.getParameter("studentId");
        String courseId = req.getParameter("courseId");
        
        // 更新成绩状态为需要重考
        scoreService.updateScoreStatus(studentId, courseId, "need_retake");
        
        // 重定向回成绩列表
        resp.sendRedirect(req.getContextPath() + "/api/teacher?action=queryScores");
    }
    
    // 修改密码方法
    private void changePassword(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 实现修改密码逻辑
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}