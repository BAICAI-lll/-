package com.exam.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.exam.model.ClassInfo;

public class ClassDAO extends BaseDAO {
    
    // 添加班级
    public boolean addClass(ClassInfo classInfo) {
        String sql = "INSERT INTO classes (class_id, class_name) VALUES (?, ?)";
        int result = executeUpdate(sql, classInfo.getClassId(), classInfo.getClassName());
        return result > 0;
    }
    
    // 删除班级
    public boolean deleteClass(String classId) {
        String sql = "DELETE FROM classes WHERE class_id = ?";
        int result = executeUpdate(sql, classId);
        return result > 0;
    }
    
    // 更新班级信息
    public boolean updateClass(ClassInfo classInfo) {
        String sql = "UPDATE classes SET class_name = ? WHERE class_id = ?";
        int result = executeUpdate(sql, classInfo.getClassName(), classInfo.getClassId());
        return result > 0;
    }
    
    // 查询所有班级
    public List<ClassInfo> getAllClasses() {
        String sql = "SELECT * FROM classes";
        return executeQuery(sql, rs -> {
            ClassInfo classInfo = new ClassInfo();
            classInfo.setClassId(rs.getString("class_id"));
            classInfo.setClassName(rs.getString("class_name"));
            return classInfo;
        });
    }
    
    // 根据ID查询班级
    public ClassInfo getClassById(String classId) {
        String sql = "SELECT * FROM classes WHERE class_id = ?";
        List<ClassInfo> classes = executeQuery(sql, rs -> {
            ClassInfo classInfo = new ClassInfo();
            classInfo.setClassId(rs.getString("class_id"));
            classInfo.setClassName(rs.getString("class_name"));
            return classInfo;
        }, classId);
        return classes.isEmpty() ? null : classes.get(0);
    }
}