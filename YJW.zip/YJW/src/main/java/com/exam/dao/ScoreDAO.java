package com.exam.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.exam.model.Score;

public class ScoreDAO extends BaseDAO {
    
    // 添加成绩
    public boolean addScore(Score score) {
        String sql = "INSERT INTO scores (student_id, course_id, score, exam_status, exam_count) VALUES (?, ?, ?, ?, ?)";
        int result = executeUpdate(sql, score.getStudentId(), score.getCourseId(), score.getScore(), score.getExamStatus(), score.getExamCount());
        return result > 0;
    }
    
    // 更新成绩
    public boolean updateScore(Score score) {
        String sql = "UPDATE scores SET score = ?, exam_status = ?, exam_count = ? WHERE student_id = ? AND course_id = ?";
        int result = executeUpdate(sql, score.getScore(), score.getExamStatus(), score.getExamCount(), score.getStudentId(), score.getCourseId());
        return result > 0;
    }
    
    // 更新成绩状态
    public boolean updateScoreStatus(String studentId, String courseId, String examStatus) {
        String sql = "UPDATE scores SET exam_status = ? WHERE student_id = ? AND course_id = ?";
        int result = executeUpdate(sql, examStatus, studentId, courseId);
        return result > 0;
    }
    
    // 增加考试次数
    public boolean incrementExamCount(String studentId, String courseId) {
        String sql = "UPDATE scores SET exam_count = exam_count + 1, exam_status = 'not_started' WHERE student_id = ? AND course_id = ?";
        int result = executeUpdate(sql, studentId, courseId);
        return result > 0;
    }
    
    // 根据学生ID和课程ID获取成绩
    public Score getScoreByStudentAndCourse(String studentId, String courseId) {
        String sql = "SELECT * FROM scores WHERE student_id = ? AND course_id = ?";
        List<Score> scores = executeQuery(sql, rs -> {
            Score score = new Score();
            score.setStudentId(rs.getString("student_id"));
            score.setCourseId(rs.getString("course_id"));
            score.setScore(rs.getDouble("score"));
            score.setExamStatus(rs.getString("exam_status"));
            score.setExamCount(rs.getInt("exam_count"));
            return score;
        }, studentId, courseId);
        return scores.isEmpty() ? null : scores.get(0);
    }
    
    // 根据学生ID查询成绩
    public List<Score> getScoresByStudentId(String studentId) {
        String sql = "SELECT * FROM scores WHERE student_id = ?";
        return executeQuery(sql, rs -> {
            Score score = new Score();
            score.setStudentId(rs.getString("student_id"));
            score.setCourseId(rs.getString("course_id"));
            score.setScore(rs.getDouble("score"));
            score.setExamStatus(rs.getString("exam_status"));
            score.setExamCount(rs.getInt("exam_count"));
            return score;
        }, studentId);
    }
    
    // 根据课程ID查询成绩
    public List<Score> getScoresByCourseId(String courseId) {
        String sql = "SELECT * FROM scores WHERE course_id = ?";
        return executeQuery(sql, rs -> {
            Score score = new Score();
            score.setStudentId(rs.getString("student_id"));
            score.setCourseId(rs.getString("course_id"));
            score.setScore(rs.getDouble("score"));
            score.setExamStatus(rs.getString("exam_status"));
            score.setExamCount(rs.getInt("exam_count"));
            return score;
        }, courseId);
    }
    
    // 根据班级和课程查询成绩
    public List<Score> getScoresByClassAndCourse(String className, String courseId) {
        String sql = "SELECT s.* FROM scores s JOIN students st ON s.student_id = st.student_id WHERE st.class_name = ? AND s.course_id = ?";
        return executeQuery(sql, rs -> {
            Score score = new Score();
            score.setStudentId(rs.getString("student_id"));
            score.setCourseId(rs.getString("course_id"));
            score.setScore(rs.getDouble("score"));
            score.setExamStatus(rs.getString("exam_status"));
            score.setExamCount(rs.getInt("exam_count"));
            return score;
        }, className, courseId);
    }
    
    // 查询所有成绩
    public List<Score> getAllScores() {
        String sql = "SELECT * FROM scores";
        return executeQuery(sql, rs -> {
            Score score = new Score();
            score.setStudentId(rs.getString("student_id"));
            score.setCourseId(rs.getString("course_id"));
            score.setScore(rs.getDouble("score"));
            score.setExamStatus(rs.getString("exam_status"));
            score.setExamCount(rs.getInt("exam_count"));
            return score;
        });
    }
}