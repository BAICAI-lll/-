package com.exam.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.exam.model.Question;

public class QuestionDAO extends BaseDAO {
    
    // 添加题目
    public boolean addQuestion(Question question) {
        String sql = "INSERT INTO questions (course_id, question_content, option_a, option_b, option_c, option_d, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?)";
        int result = executeUpdate(sql, question.getCourseId(), question.getQuestionContent(), 
                question.getOptionA(), question.getOptionB(), question.getOptionC(), question.getOptionD(), question.getCorrectAnswer());
        return result > 0;
    }
    
    // 删除题目
    public boolean deleteQuestion(int questionId) {
        String sql = "DELETE FROM questions WHERE question_id = ?";
        int result = executeUpdate(sql, questionId);
        return result > 0;
    }
    
    // 更新题目
    public boolean updateQuestion(Question question) {
        String sql = "UPDATE questions SET course_id = ?, question_content = ?, option_a = ?, option_b = ?, option_c = ?, option_d = ?, correct_answer = ? WHERE question_id = ?";
        int result = executeUpdate(sql, question.getCourseId(), question.getQuestionContent(), 
                question.getOptionA(), question.getOptionB(), question.getOptionC(), question.getOptionD(), question.getCorrectAnswer(), question.getQuestionId());
        return result > 0;
    }
    
    // 根据课程ID查询题目
    public List<Question> getQuestionsByCourseId(String courseId) {
        String sql = "SELECT * FROM questions WHERE course_id = ?";
        return executeQuery(sql, rs -> {
            Question question = new Question();
            question.setQuestionId(rs.getInt("question_id"));
            question.setCourseId(rs.getString("course_id"));
            question.setQuestionContent(rs.getString("question_content"));
            question.setOptionA(rs.getString("option_a"));
            question.setOptionB(rs.getString("option_b"));
            question.setOptionC(rs.getString("option_c"));
            question.setOptionD(rs.getString("option_d"));
            question.setCorrectAnswer(rs.getString("correct_answer"));
            return question;
        }, courseId);
    }
    
    // 根据ID查询题目
    public Question getQuestionById(int questionId) {
        String sql = "SELECT * FROM questions WHERE question_id = ?";
        List<Question> questions = executeQuery(sql, rs -> {
            Question question = new Question();
            question.setQuestionId(rs.getInt("question_id"));
            question.setCourseId(rs.getString("course_id"));
            question.setQuestionContent(rs.getString("question_content"));
            question.setOptionA(rs.getString("option_a"));
            question.setOptionB(rs.getString("option_b"));
            question.setOptionC(rs.getString("option_c"));
            question.setOptionD(rs.getString("option_d"));
            question.setCorrectAnswer(rs.getString("correct_answer"));
            return question;
        }, questionId);
        return questions.isEmpty() ? null : questions.get(0);
    }
    
    // 查询所有题目
    public List<Question> getAllQuestions() {
        String sql = "SELECT * FROM questions";
        return executeQuery(sql, rs -> {
            Question question = new Question();
            question.setQuestionId(rs.getInt("question_id"));
            question.setCourseId(rs.getString("course_id"));
            question.setQuestionContent(rs.getString("question_content"));
            question.setOptionA(rs.getString("option_a"));
            question.setOptionB(rs.getString("option_b"));
            question.setOptionC(rs.getString("option_c"));
            question.setOptionD(rs.getString("option_d"));
            question.setCorrectAnswer(rs.getString("correct_answer"));
            return question;
        });
    }
}