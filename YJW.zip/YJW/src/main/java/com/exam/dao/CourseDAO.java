package com.exam.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.exam.model.Course;

public class CourseDAO extends BaseDAO {
    
    // 添加课程
    public boolean addCourse(Course course) {
        String sql = "INSERT INTO courses (course_id, course_name, teacher_id) VALUES (?, ?, ?)";
        int result = executeUpdate(sql, course.getCourseId(), course.getCourseName(), course.getTeacherId());
        return result > 0;
    }
    
    // 删除课程
    public boolean deleteCourse(String courseId) {
        String sql = "DELETE FROM courses WHERE course_id = ?";
        int result = executeUpdate(sql, courseId);
        return result > 0;
    }
    
    // 更新课程信息
    public boolean updateCourse(Course course) {
        String sql = "UPDATE courses SET course_name = ?, teacher_id = ? WHERE course_id = ?";
        int result = executeUpdate(sql, course.getCourseName(), course.getTeacherId(), course.getCourseId());
        return result > 0;
    }
    
    // 查询所有课程
    public List<Course> getAllCourses() {
        String sql = "SELECT * FROM courses";
        return executeQuery(sql, rs -> {
            Course course = new Course();
            course.setCourseId(rs.getString("course_id"));
            course.setCourseName(rs.getString("course_name"));
            course.setTeacherId(rs.getString("teacher_id"));
            return course;
        });
    }
    
    // 根据ID查询课程
    public Course getCourseById(String courseId) {
        String sql = "SELECT * FROM courses WHERE course_id = ?";
        List<Course> courses = executeQuery(sql, rs -> {
            Course course = new Course();
            course.setCourseId(rs.getString("course_id"));
            course.setCourseName(rs.getString("course_name"));
            course.setTeacherId(rs.getString("teacher_id"));
            return course;
        }, courseId);
        return courses.isEmpty() ? null : courses.get(0);
    }
    
    // 根据教师ID查询课程
    public List<Course> getCoursesByTeacherId(String teacherId) {
        String sql = "SELECT * FROM courses WHERE teacher_id = ?";
        return executeQuery(sql, rs -> {
            Course course = new Course();
            course.setCourseId(rs.getString("course_id"));
            course.setCourseName(rs.getString("course_name"));
            course.setTeacherId(rs.getString("teacher_id"));
            return course;
        }, teacherId);
    }
}