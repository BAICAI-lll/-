package com.exam.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.exam.model.Student;

public class StudentDAO extends BaseDAO {
    
    // 添加学生
    public boolean addStudent(Student student) {
        String sql = "INSERT INTO students (student_id, name, gender, class_name) VALUES (?, ?, ?, ?)";
        int result = executeUpdate(sql, student.getStudentId(), student.getName(), student.getGender(), student.getClassName());
        return result > 0;
    }
    
    // 删除学生
    public boolean deleteStudent(String studentId) {
        String sql = "DELETE FROM students WHERE student_id = ?";
        int result = executeUpdate(sql, studentId);
        return result > 0;
    }
    
    // 更新学生信息
    public boolean updateStudent(Student student) {
        String sql = "UPDATE students SET name = ?, gender = ?, class_name = ? WHERE student_id = ?";
        int result = executeUpdate(sql, student.getName(), student.getGender(), student.getClassName(), student.getStudentId());
        return result > 0;
    }
    
    // 查询所有学生
    public List<Student> getAllStudents() {
        String sql = "SELECT * FROM students";
        return executeQuery(sql, rs -> {
            Student student = new Student();
            student.setStudentId(rs.getString("student_id"));
            student.setName(rs.getString("name"));
            student.setGender(rs.getString("gender"));
            student.setClassName(rs.getString("class_name"));
            return student;
        });
    }
    
    // 根据ID查询学生
    public Student getStudentById(String studentId) {
        String sql = "SELECT * FROM students WHERE student_id = ?";
        List<Student> students = executeQuery(sql, rs -> {
            Student student = new Student();
            student.setStudentId(rs.getString("student_id"));
            student.setName(rs.getString("name"));
            student.setGender(rs.getString("gender"));
            student.setClassName(rs.getString("class_name"));
            return student;
        }, studentId);
        return students.isEmpty() ? null : students.get(0);
    }
    
    // 根据班级查询学生
    public List<Student> getStudentsByClass(String className) {
        String sql = "SELECT * FROM students WHERE class_name = ?";
        return executeQuery(sql, rs -> {
            Student student = new Student();
            student.setStudentId(rs.getString("student_id"));
            student.setName(rs.getString("name"));
            student.setGender(rs.getString("gender"));
            student.setClassName(rs.getString("class_name"));
            return student;
        }, className);
    }
}