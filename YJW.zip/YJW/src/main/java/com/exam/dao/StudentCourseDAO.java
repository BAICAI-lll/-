package com.exam.dao;

import java.util.List;
import com.exam.model.Course;

public class StudentCourseDAO extends BaseDAO {
    
    // 学生选择课程
    public boolean addStudentCourse(String studentId, String courseId) {
        String sql = "INSERT INTO student_courses (student_id, course_id) VALUES (?, ?)";
        int result = executeUpdate(sql, studentId, courseId);
        return result > 0;
    }
    
    // 学生取消选择课程
    public boolean deleteStudentCourse(String studentId, String courseId) {
        String sql = "DELETE FROM student_courses WHERE student_id = ? AND course_id = ?";
        int result = executeUpdate(sql, studentId, courseId);
        return result > 0;
    }
    
    // 根据学生ID获取所选课程
    public List<Course> getCoursesByStudentId(String studentId) {
        String sql = "SELECT c.* FROM courses c JOIN student_courses sc ON c.course_id = sc.course_id WHERE sc.student_id = ?";
        return executeQuery(sql, rs -> {
            Course course = new Course();
            course.setCourseId(rs.getString("course_id"));
            course.setCourseName(rs.getString("course_name"));
            course.setTeacherId(rs.getString("teacher_id"));
            return course;
        }, studentId);
    }
    
    // 检查学生是否已选择该课程
    public boolean isCourseSelected(String studentId, String courseId) {
        String sql = "SELECT COUNT(*) FROM student_courses WHERE student_id = ? AND course_id = ?";
        return executeQuery(sql, rs -> {
            return rs.next() && rs.getInt(1) > 0;
        }, studentId, courseId).get(0);
    }
    
    // 获取学生未选择的课程
    public List<Course> getAvailableCourses(String studentId) {
        String sql = "SELECT * FROM courses WHERE course_id NOT IN (SELECT course_id FROM student_courses WHERE student_id = ?)";
        return executeQuery(sql, rs -> {
            Course course = new Course();
            course.setCourseId(rs.getString("course_id"));
            course.setCourseName(rs.getString("course_name"));
            course.setTeacherId(rs.getString("teacher_id"));
            return course;
        }, studentId);
    }
}