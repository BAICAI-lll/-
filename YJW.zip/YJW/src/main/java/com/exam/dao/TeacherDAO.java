package com.exam.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.exam.model.Teacher;

public class TeacherDAO extends BaseDAO {
    
    // 添加教师
    public boolean addTeacher(Teacher teacher) {
        String sql = "INSERT INTO teachers (teacher_id, name, gender, phone) VALUES (?, ?, ?, ?)";
        int result = executeUpdate(sql, teacher.getTeacherId(), teacher.getName(), teacher.getGender(), teacher.getPhone());
        return result > 0;
    }
    
    // 删除教师
    public boolean deleteTeacher(String teacherId) {
        String sql = "DELETE FROM teachers WHERE teacher_id = ?";
        int result = executeUpdate(sql, teacherId);
        return result > 0;
    }
    
    // 更新教师信息
    public boolean updateTeacher(Teacher teacher) {
        String sql = "UPDATE teachers SET name = ?, gender = ?, phone = ? WHERE teacher_id = ?";
        int result = executeUpdate(sql, teacher.getName(), teacher.getGender(), teacher.getPhone(), teacher.getTeacherId());
        return result > 0;
    }
    
    // 查询所有教师
    public List<Teacher> getAllTeachers() {
        String sql = "SELECT * FROM teachers";
        return executeQuery(sql, rs -> {
            Teacher teacher = new Teacher();
            teacher.setTeacherId(rs.getString("teacher_id"));
            teacher.setName(rs.getString("name"));
            teacher.setGender(rs.getString("gender"));
            teacher.setPhone(rs.getString("phone"));
            return teacher;
        });
    }
    
    // 根据ID查询教师
    public Teacher getTeacherById(String teacherId) {
        String sql = "SELECT * FROM teachers WHERE teacher_id = ?";
        List<Teacher> teachers = executeQuery(sql, rs -> {
            Teacher teacher = new Teacher();
            teacher.setTeacherId(rs.getString("teacher_id"));
            teacher.setName(rs.getString("name"));
            teacher.setGender(rs.getString("gender"));
            teacher.setPhone(rs.getString("phone"));
            return teacher;
        }, teacherId);
        return teachers.isEmpty() ? null : teachers.get(0);
    }
}