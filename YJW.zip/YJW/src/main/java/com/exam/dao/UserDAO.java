package com.exam.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.exam.model.User;
import com.exam.util.DBUtil;

public class UserDAO extends BaseDAO {
    
    // 用户登录验证
    public User login(String username, String password, String role) {
        // 处理角色值的中英文转换
        String dbRole = role;
        if ("管理员".equals(role)) {
            dbRole = "admin";
        } else if ("教师".equals(role)) {
            dbRole = "teacher";
        } else if ("学生".equals(role)) {
            dbRole = "student";
        }
        
        String sql = "SELECT * FROM users WHERE username = ? AND password = ? AND role = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        User user = null;
        
        try {
            conn = DBUtil.getStaticConnection();
            if (conn == null) {
                System.err.println("数据库连接失败");
                return null;
            }
            ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, dbRole);
            
            rs = ps.executeQuery();
            if (rs != null && rs.next()) {
                // 获取所有字段，包括userId和class_course_id
                user = new User(
                    rs.getString("username"), 
                    rs.getString("password"), 
                    rs.getString("role"),
                    rs.getString("user_id"),
                    rs.getString("class_course_id")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeStatic(conn, ps, rs);
        }
        return user;
    }
    
    // 修改密码
    public boolean changePassword(String username, String oldPassword, String newPassword) {
        String sql = "UPDATE users SET password = ? WHERE username = ? AND password = ?";
        int result = executeUpdate(sql, newPassword, username, oldPassword);
        return result > 0;
    }
    
    // 添加用户
    public boolean addUser(User user) {
        String sql = "INSERT INTO users (username, password, role, user_id, class_course_id) VALUES (?, ?, ?, ?, ?)";
        int result = executeUpdate(sql, user.getUsername(), user.getPassword(), user.getRole(), user.getUserId(), user.getClassCourseId());
        return result > 0;
    }
    
    // 删除用户
    public boolean deleteUser(String username) {
        String sql = "DELETE FROM users WHERE username = ?";
        int result = executeUpdate(sql, username);
        return result > 0;
    }
    
    // 更新用户信息
    public boolean updateUser(User user) {
        String sql = "UPDATE users SET password = ?, role = ?, user_id = ?, class_course_id = ? WHERE username = ?";
        int result = executeUpdate(sql, user.getPassword(), user.getRole(), user.getUserId(), user.getClassCourseId(), user.getUsername());
        return result > 0;
    }
    
    // 获取所有用户
    public java.util.List<User> getAllUsers() {
        String sql = "SELECT * FROM users";
        return executeQuery(sql, rs -> {
            User user = new User();
            user.setUsername(rs.getString("username"));
            user.setPassword(rs.getString("password"));
            user.setRole(rs.getString("role"));
            user.setUserId(rs.getString("user_id"));
            user.setClassCourseId(rs.getString("class_course_id"));
            return user;
        });
    }
}