package com.exam.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.exam.util.DBUtil;

public class BaseDAO {
    // 通用查询方法
    protected <T> List<T> executeQuery(String sql, ResultSetHandler<T> handler, Object... params) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<T> resultList = new ArrayList<>();
        
        try {
            conn = DBUtil.getStaticConnection();
            if (conn == null) {
                System.err.println("数据库连接失败");
                return resultList;
            }
            ps = conn.prepareStatement(sql);
            
            // 设置参数
            if (params != null && params.length > 0) {
                for (int i = 0; i < params.length; i++) {
                    ps.setObject(i + 1, params[i]);
                }
            }
            
            rs = ps.executeQuery();
            while (rs != null && rs.next()) {
                T result = handler.handle(rs);
                resultList.add(result);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeStatic(conn, ps, rs);
        }
        return resultList;
    }
    
    // 结果集处理器接口
    protected interface ResultSetHandler<T> {
        T handle(ResultSet rs) throws SQLException;
    }
    
    // 通用更新方法（插入、更新、删除）
    protected int executeUpdate(String sql, Object... params) {
        Connection conn = null;
        PreparedStatement ps = null;
        
        try {
            conn = DBUtil.getStaticConnection();
            ps = conn.prepareStatement(sql);
            
            // 设置参数
            if (params != null && params.length > 0) {
                for (int i = 0; i < params.length; i++) {
                    ps.setObject(i + 1, params[i]);
                }
            }
            
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        } finally {
            DBUtil.closeStatic(conn, ps, null);
        }
    }
}