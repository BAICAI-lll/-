package com.exam.model;

import java.util.ArrayList;
import java.util.List;

// 组合角色 - 组合节点
public class CompositeRole extends RoleComponent {
    private List<RoleComponent> roles = new ArrayList<>();
    
    public CompositeRole(String name, String description) {
        super(name, description);
    }
    
    @Override
    public void add(RoleComponent role) {
        roles.add(role);
    }
    
    @Override
    public void remove(RoleComponent role) {
        roles.remove(role);
    }
    
    @Override
    public RoleComponent getChild(int index) {
        return roles.get(index);
    }
    
    @Override
    public boolean isComposite() {
        return true;
    }
    
    @Override
    public void executePermission() {
        System.out.println("执行组合角色 '" + name + "' 的权限");
        for (RoleComponent role : roles) {
            role.executePermission();
        }
    }
    
    // 获取子角色数量
    public int getChildCount() {
        return roles.size();
    }
}