package com.exam.model;

// 教师角色 - 叶子节点
public class TeacherRole extends RoleComponent {
    public TeacherRole() {
        super("teacher", "教师角色");
    }
    
    @Override
    public void executePermission() {
        System.out.println("执行教师权限: 管理题目、批改成绩、查看学生");
    }
}