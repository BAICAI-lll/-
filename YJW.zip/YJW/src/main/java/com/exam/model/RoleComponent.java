package com.exam.model;

// 角色组件抽象类 - 组合模式（结构型）
public abstract class RoleComponent {
    protected String name;
    protected String description;
    
    public RoleComponent(String name, String description) {
        this.name = name;
        this.description = description;
    }
    
    // 添加子角色（默认实现，组合节点会重写）
    public void add(RoleComponent role) {
        throw new UnsupportedOperationException("不支持添加操作");
    }
    
    // 移除子角色（默认实现，组合节点会重写）
    public void remove(RoleComponent role) {
        throw new UnsupportedOperationException("不支持移除操作");
    }
    
    // 获取子角色（默认实现，组合节点会重写）
    public RoleComponent getChild(int index) {
        throw new UnsupportedOperationException("不支持获取子角色操作");
    }
    
    // 检查是否为组合节点
    public boolean isComposite() {
        return false;
    }
    
    // 执行角色权限（抽象方法，所有角色都必须实现）
    public abstract void executePermission();
    
    // 获取角色信息
    public String getName() {
        return name;
    }
    
    public String getDescription() {
        return description;
    }
}