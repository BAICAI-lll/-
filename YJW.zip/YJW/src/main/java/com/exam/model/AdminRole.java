package com.exam.model;

// 管理员角色 - 叶子节点
public class AdminRole extends RoleComponent {
    public AdminRole() {
        super("admin", "管理员角色");
    }
    
    @Override
    public void executePermission() {
        System.out.println("执行管理员权限: 管理用户、管理课程、管理班级");
    }
}