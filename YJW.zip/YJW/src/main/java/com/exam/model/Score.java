package com.exam.model;

public class Score {
    private String studentId;
    private String courseId;
    private double score;
    private String examStatus; // not_started, submitted, passed, need_retake
    private int examCount;
    
    public Score() {
    }
    
    public Score(String studentId, String courseId, double score) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.score = score;
        this.examStatus = "submitted";
        this.examCount = 1;
    }
    
    public Score(String studentId, String courseId, double score, String examStatus, int examCount) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.score = score;
        this.examStatus = examStatus;
        this.examCount = examCount;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }
    
    public double getScore() {
        return score;
    }
    
    public void setScore(double score) {
        this.score = score;
    }
    
    public String getExamStatus() {
        return examStatus;
    }
    
    public void setExamStatus(String examStatus) {
        this.examStatus = examStatus;
    }
    
    public int getExamCount() {
        return examCount;
    }
    
    public void setExamCount(int examCount) {
        this.examCount = examCount;
    }
}