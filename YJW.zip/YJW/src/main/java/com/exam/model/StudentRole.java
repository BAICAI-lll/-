package com.exam.model;

// 学生角色 - 叶子节点
public class StudentRole extends RoleComponent {
    public StudentRole() {
        super("student", "学生角色");
    }
    
    @Override
    public void executePermission() {
        System.out.println("执行学生权限: 查看课程、参加考试、查看成绩");
    }
}