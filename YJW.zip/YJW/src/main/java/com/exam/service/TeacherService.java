package com.exam.service;

import java.util.List;
import com.exam.dao.TeacherDAO;
import com.exam.model.Teacher;

public class TeacherService {
    private TeacherDAO teacherDAO = new TeacherDAO();
    
    // 添加教师
    public boolean addTeacher(Teacher teacher) {
        return teacherDAO.addTeacher(teacher);
    }
    
    // 删除教师
    public boolean deleteTeacher(String teacherId) {
        return teacherDAO.deleteTeacher(teacherId);
    }
    
    // 更新教师信息
    public boolean updateTeacher(Teacher teacher) {
        return teacherDAO.updateTeacher(teacher);
    }
    
    // 获取所有教师
    public List<Teacher> getAllTeachers() {
        return teacherDAO.getAllTeachers();
    }
    
    // 根据ID获取教师
    public Teacher getTeacherById(String teacherId) {
        return teacherDAO.getTeacherById(teacherId);
    }
}