package com.exam.service;

import java.util.List;
import com.exam.dao.StudentDAO;
import com.exam.model.Student;

public class StudentService {
    private StudentDAO studentDAO = new StudentDAO();
    
    // 添加学生
    public boolean addStudent(Student student) {
        return studentDAO.addStudent(student);
    }
    
    // 删除学生
    public boolean deleteStudent(String studentId) {
        return studentDAO.deleteStudent(studentId);
    }
    
    // 更新学生信息
    public boolean updateStudent(Student student) {
        return studentDAO.updateStudent(student);
    }
    
    // 获取所有学生
    public List<Student> getAllStudents() {
        return studentDAO.getAllStudents();
    }
    
    // 根据ID获取学生
    public Student getStudentById(String studentId) {
        return studentDAO.getStudentById(studentId);
    }
    
    // 根据班级获取学生
    public List<Student> getStudentsByClass(String className) {
        return studentDAO.getStudentsByClass(className);
    }
}