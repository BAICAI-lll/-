package com.exam.service;

import java.util.List;
import com.exam.dao.ScoreDAO;
import com.exam.model.Score;

public class ScoreService {
    private ScoreDAO scoreDAO = new ScoreDAO();
    
    // 添加成绩
    public boolean addScore(Score score) {
        return scoreDAO.addScore(score);
    }
    
    // 更新成绩
    public boolean updateScore(Score score) {
        return scoreDAO.updateScore(score);
    }
    
    // 根据学生ID获取成绩
    public List<Score> getScoresByStudentId(String studentId) {
        return scoreDAO.getScoresByStudentId(studentId);
    }
    
    // 根据课程ID获取成绩
    public List<Score> getScoresByCourseId(String courseId) {
        return scoreDAO.getScoresByCourseId(courseId);
    }
    
    // 根据班级和课程获取成绩
    public List<Score> getScoresByClassAndCourse(String className, String courseId) {
        return scoreDAO.getScoresByClassAndCourse(className, courseId);
    }
    
    // 获取所有成绩
    public List<Score> getAllScores() {
        return scoreDAO.getAllScores();
    }
    
    // 根据学生ID和课程ID获取成绩
    public Score getScoreByStudentAndCourse(String studentId, String courseId) {
        return scoreDAO.getScoreByStudentAndCourse(studentId, courseId);
    }
    
    // 更新成绩状态
    public boolean updateScoreStatus(String studentId, String courseId, String status) {
        return scoreDAO.updateScoreStatus(studentId, courseId, status);
    }
}