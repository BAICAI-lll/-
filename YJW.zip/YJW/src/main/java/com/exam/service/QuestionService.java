package com.exam.service;

import java.util.List;
import com.exam.dao.QuestionDAO;
import com.exam.model.Question;

public class QuestionService {
    private QuestionDAO questionDAO = new QuestionDAO();
    
    // 添加题目
    public boolean addQuestion(Question question) {
        return questionDAO.addQuestion(question);
    }
    
    // 删除题目
    public boolean deleteQuestion(int questionId) {
        return questionDAO.deleteQuestion(questionId);
    }
    
    // 更新题目
    public boolean updateQuestion(Question question) {
        return questionDAO.updateQuestion(question);
    }
    
    // 根据课程ID获取题目
    public List<Question> getQuestionsByCourseId(String courseId) {
        return questionDAO.getQuestionsByCourseId(courseId);
    }
    
    // 根据ID获取题目
    public Question getQuestionById(int questionId) {
        return questionDAO.getQuestionById(questionId);
    }
    
    // 获取所有题目
    public List<Question> getAllQuestions() {
        return questionDAO.getAllQuestions();
    }
}