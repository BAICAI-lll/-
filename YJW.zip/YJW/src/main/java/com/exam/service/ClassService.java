package com.exam.service;

import java.util.List;
import com.exam.dao.ClassDAO;
import com.exam.model.ClassInfo;

public class ClassService {
    private ClassDAO classDAO = new ClassDAO();
    
    // 添加班级
    public boolean addClass(ClassInfo classInfo) {
        return classDAO.addClass(classInfo);
    }
    
    // 删除班级
    public boolean deleteClass(String classId) {
        return classDAO.deleteClass(classId);
    }
    
    // 更新班级信息
    public boolean updateClass(ClassInfo classInfo) {
        return classDAO.updateClass(classInfo);
    }
    
    // 获取所有班级
    public List<ClassInfo> getAllClasses() {
        return classDAO.getAllClasses();
    }
    
    // 根据ID获取班级
    public ClassInfo getClassById(String classId) {
        return classDAO.getClassById(classId);
    }
}