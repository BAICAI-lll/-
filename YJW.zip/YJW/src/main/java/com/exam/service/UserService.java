package com.exam.service;

import com.exam.dao.UserDAO;
import com.exam.model.User;

public class UserService {
    private UserDAO userDAO = new UserDAO();
    
    // 用户登录
    public User login(String username, String password, String role) {
        return userDAO.login(username, password, role);
    }
    
    // 修改密码
    public boolean changePassword(String username, String oldPassword, String newPassword) {
        return userDAO.changePassword(username, oldPassword, newPassword);
    }
    
    // 添加用户
    public boolean addUser(User user) {
        return userDAO.addUser(user);
    }
    
    // 删除用户
    public boolean deleteUser(String username) {
        return userDAO.deleteUser(username);
    }
    
    // 更新用户
    public boolean updateUser(User user) {
        return userDAO.updateUser(user);
    }
    
    // 获取所有用户
    public java.util.List<User> getAllUsers() {
        return userDAO.getAllUsers();
    }
}