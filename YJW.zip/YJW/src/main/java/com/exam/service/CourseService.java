package com.exam.service;

import java.util.List;
import com.exam.dao.CourseDAO;
import com.exam.model.Course;

public class CourseService {
    private CourseDAO courseDAO = new CourseDAO();
    
    // 添加课程
    public boolean addCourse(Course course) {
        return courseDAO.addCourse(course);
    }
    
    // 删除课程
    public boolean deleteCourse(String courseId) {
        return courseDAO.deleteCourse(courseId);
    }
    
    // 更新课程信息
    public boolean updateCourse(Course course) {
        return courseDAO.updateCourse(course);
    }
    
    // 获取所有课程
    public List<Course> getAllCourses() {
        return courseDAO.getAllCourses();
    }
    
    // 根据ID获取课程
    public Course getCourseById(String courseId) {
        return courseDAO.getCourseById(courseId);
    }
    
    // 根据教师ID获取课程
    public List<Course> getCoursesByTeacherId(String teacherId) {
        return courseDAO.getCoursesByTeacherId(teacherId);
    }
}