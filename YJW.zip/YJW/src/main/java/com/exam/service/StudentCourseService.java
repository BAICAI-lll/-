package com.exam.service;

import java.util.List;
import com.exam.dao.StudentCourseDAO;
import com.exam.model.Course;

public class StudentCourseService {
    private StudentCourseDAO studentCourseDAO = new StudentCourseDAO();
    
    // 学生选择课程
    public boolean addStudentCourse(String studentId, String courseId) {
        return studentCourseDAO.addStudentCourse(studentId, courseId);
    }
    
    // 学生取消选择课程
    public boolean deleteStudentCourse(String studentId, String courseId) {
        return studentCourseDAO.deleteStudentCourse(studentId, courseId);
    }
    
    // 根据学生ID获取所选课程
    public List<Course> getCoursesByStudentId(String studentId) {
        return studentCourseDAO.getCoursesByStudentId(studentId);
    }
    
    // 检查学生是否已选择该课程
    public boolean isCourseSelected(String studentId, String courseId) {
        return studentCourseDAO.isCourseSelected(studentId, courseId);
    }
    
    // 获取学生未选择的课程
    public List<Course> getAvailableCourses(String studentId) {
        return studentCourseDAO.getAvailableCourses(studentId);
    }
}