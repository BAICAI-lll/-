package com.exam.util;

// 日志管理器 - 结合单例模式
public class LoggerManager {
    private static volatile LoggerManager instance;
    private Logger logger;
    
    private LoggerManager() {
        // 创建带有时间戳装饰的控制台日志
        this.logger = new TimestampLoggerDecorator(new ConsoleLogger());
    }
    
    public static LoggerManager getInstance() {
        if (instance == null) {
            synchronized (LoggerManager.class) {
                if (instance == null) {
                    instance = new LoggerManager();
                }
            }
        }
        return instance;
    }
    
    public Logger getLogger() {
        return logger;
    }
    
    // 静态方法，方便直接使用
    public static void log(String message) {
        getInstance().getLogger().log(message);
    }
    
    public static void logError(String message, Throwable e) {
        getInstance().getLogger().logError(message, e);
    }
}