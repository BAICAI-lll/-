package com.exam.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

// 单例模式 - 创建型模式
public class DBUtil {
    private static final String URL = "jdbc:mysql://localhost:3306/exam_system?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=Asia/Shanghai";
    private static final String USER = "root";
    private static final String PASSWORD = "123456";
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    
    // 单例实例，使用volatile确保多线程下的可见性
    private static volatile DBUtil instance;
    
    // 私有构造方法，防止外部实例化
    private DBUtil() {
        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    // 双重检查锁定实现单例模式
    public static DBUtil getInstance() {
        if (instance == null) {
            synchronized (DBUtil.class) {
                if (instance == null) {
                    instance = new DBUtil();
                }
            }
        }
        return instance;
    }
    
    // 获取数据库连接
    public Connection getConnection() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }
    
    // 关闭资源
    public void close(Connection conn, PreparedStatement ps, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // 保留静态方法作为兼容层
    public static Connection getStaticConnection() {
        return getInstance().getConnection();
    }
    
    // 保留静态方法作为兼容层
    public static void closeStatic(Connection conn, PreparedStatement ps, ResultSet rs) {
        getInstance().close(conn, ps, rs);
    }
}