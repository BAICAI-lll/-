package com.exam.util;

// 日志装饰器抽象类 - 装饰器模式（结构型）
public abstract class LoggerDecorator implements Logger {
    protected Logger logger;
    
    public LoggerDecorator(Logger logger) {
        this.logger = logger;
    }
    
    @Override
    public void log(String message) {
        logger.log(message);
    }
    
    @Override
    public void logError(String message, Throwable e) {
        logger.logError(message, e);
    }
}