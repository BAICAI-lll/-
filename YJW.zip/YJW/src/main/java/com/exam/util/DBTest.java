package com.exam.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBTest {
    public static void main(String[] args) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            // 获取数据库连接
            conn = DBUtil.getStaticConnection();
            System.out.println("数据库连接: " + (conn != null ? "成功" : "失败"));
            
            if (conn != null) {
                // 测试查询教师表数据
                String sql = "SELECT * FROM teachers";
                ps = conn.prepareStatement(sql);
                rs = ps.executeQuery();
                
                System.out.println("\n教师表数据:");
                System.out.println("教师ID\t姓名\t性别\t电话");
                while (rs.next()) {
                    String teacherId = rs.getString("teacher_id");
                    String name = rs.getString("name");
                    String gender = rs.getString("gender");
                    String phone = rs.getString("phone");
                    System.out.println(teacherId + "\t" + name + "\t" + gender + "\t" + phone);
                }
                
                // 测试查询课程表数据
                sql = "SELECT * FROM courses";
                ps = conn.prepareStatement(sql);
                rs = ps.executeQuery();
                
                System.out.println("\n课程表数据:");
                System.out.println("课程ID\t课程名称\t教师ID");
                while (rs.next()) {
                    String courseId = rs.getString("course_id");
                    String courseName = rs.getString("course_name");
                    String teacherId = rs.getString("teacher_id");
                    System.out.println(courseId + "\t" + courseName + "\t" + teacherId);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeStatic(conn, ps, rs);
        }
    }
}