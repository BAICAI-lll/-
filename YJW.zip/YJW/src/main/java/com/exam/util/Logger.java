package com.exam.util;

// 日志记录接口
public interface Logger {
    void log(String message);
    void logError(String message, Throwable e);
}