package com.exam.util;

import java.text.SimpleDateFormat;
import java.util.Date;

// 时间戳日志装饰器 - 具体装饰器
public class TimestampLoggerDecorator extends LoggerDecorator {
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    public TimestampLoggerDecorator(Logger logger) {
        super(logger);
    }
    
    @Override
    public void log(String message) {
        String timestamp = sdf.format(new Date());
        logger.log(timestamp + " " + message);
    }
    
    @Override
    public void logError(String message, Throwable e) {
        String timestamp = sdf.format(new Date());
        logger.logError(timestamp + " " + message, e);
    }
}