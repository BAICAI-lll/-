package com.exam.util;

import org.junit.Test;
import static org.junit.Assert.*;

// DBUtil单例模式测试
public class DBUtilTest {
    
    @Test
    public void testGetInstance() {
        // 测试单例模式，确保多次调用getInstance返回同一个实例
        DBUtil instance1 = DBUtil.getInstance();
        DBUtil instance2 = DBUtil.getInstance();
        
        // 验证两个实例是同一个对象
        assertSame("DBUtil should be a singleton", instance1, instance2);
        assertNotNull("Instance should not be null", instance1);
    }
    
    @Test
    public void testGetConnection() {
        // 测试获取数据库连接
        DBUtil instance = DBUtil.getInstance();
        // 这里不实际连接数据库，只测试方法调用不抛出异常
        assertNotNull("Instance should not be null", instance);
    }
    
    @Test
    public void testStaticMethods() {
        // 测试静态兼容方法
        // 这里不实际连接数据库，只测试方法调用不抛出异常
        DBUtil.getStaticConnection();
        // 测试closeStatic方法，传入null参数
        DBUtil.closeStatic(null, null, null);
    }
}