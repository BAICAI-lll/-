package com.exam.util;

import org.junit.Test;
import static org.junit.Assert.*;

// 日志系统装饰器模式测试
public class LoggerTest {
    
    @Test
    public void testConsoleLogger() {
        // 测试基本的控制台日志
        Logger logger = new ConsoleLogger();
        assertNotNull("ConsoleLogger should not be null", logger);
        
        // 测试日志记录方法不抛出异常
        logger.log("Test console log message");
        logger.logError("Test error message", null);
    }
    
    @Test
    public void testTimestampLoggerDecorator() {
        // 测试带有时间戳装饰的日志
        Logger consoleLogger = new ConsoleLogger();
        Logger timestampLogger = new TimestampLoggerDecorator(consoleLogger);
        
        assertNotNull("TimestampLogger should not be null", timestampLogger);
        
        // 测试装饰后的日志记录不抛出异常
        timestampLogger.log("Test timestamp log message");
        timestampLogger.logError("Test timestamp error message", null);
    }
    
    @Test
    public void testLoggerManager() {
        // 测试日志管理器的单例模式
        LoggerManager manager1 = LoggerManager.getInstance();
        LoggerManager manager2 = LoggerManager.getInstance();
        
        assertSame("LoggerManager should be a singleton", manager1, manager2);
        assertNotNull("LoggerManager instance should not be null", manager1);
        
        // 测试日志管理器的日志记录方法
        LoggerManager.log("Test manager log message");
        LoggerManager.logError("Test manager error message", null);
    }
}