package com.exam.model;

import org.junit.Test;
import static org.junit.Assert.*;

// 组合模式测试
public class RoleCompositeTest {
    
    @Test
    public void testLeafRoles() {
        // 测试叶子节点角色
        RoleComponent studentRole = new StudentRole();
        RoleComponent teacherRole = new TeacherRole();
        RoleComponent adminRole = new AdminRole();
        
        assertNotNull("StudentRole should not be null", studentRole);
        assertNotNull("TeacherRole should not be null", teacherRole);
        assertNotNull("AdminRole should not be null", adminRole);
        
        // 验证叶子节点不是组合节点
        assertFalse("StudentRole should not be composite", studentRole.isComposite());
        assertFalse("TeacherRole should not be composite", teacherRole.isComposite());
        assertFalse("AdminRole should not be composite", adminRole.isComposite());
        
        // 测试执行权限方法不抛出异常
        studentRole.executePermission();
        teacherRole.executePermission();
        adminRole.executePermission();
    }
    
    @Test
    public void testCompositeRole() {
        // 测试组合角色
        CompositeRole allRoles = new CompositeRole("allRoles", "所有角色组合");
        
        // 验证组合节点是组合节点
        assertTrue("CompositeRole should be composite", allRoles.isComposite());
        
        // 创建叶子节点
        RoleComponent studentRole = new StudentRole();
        RoleComponent teacherRole = new TeacherRole();
        RoleComponent adminRole = new AdminRole();
        
        // 添加叶子节点到组合节点
        allRoles.add(studentRole);
        allRoles.add(teacherRole);
        allRoles.add(adminRole);
        
        // 验证子角色数量
        assertEquals("CompositeRole should have 3 children", 3, allRoles.getChildCount());
        
        // 验证子角色可以被获取
        assertNotNull("Child 0 should not be null", allRoles.getChild(0));
        assertNotNull("Child 1 should not be null", allRoles.getChild(1));
        assertNotNull("Child 2 should not be null", allRoles.getChild(2));
        
        // 测试执行组合角色权限，应该执行所有子角色的权限
        allRoles.executePermission();
        
        // 测试移除子角色
        allRoles.remove(studentRole);
        assertEquals("CompositeRole should have 2 children after removal", 2, allRoles.getChildCount());
    }
    
    @Test(expected = UnsupportedOperationException.class)
    public void testLeafAddOperation() {
        // 测试叶子节点不支持添加操作
        RoleComponent studentRole = new StudentRole();
        RoleComponent teacherRole = new TeacherRole();
        studentRole.add(teacherRole); // 应该抛出异常
    }
    
    @Test(expected = UnsupportedOperationException.class)
    public void testLeafRemoveOperation() {
        // 测试叶子节点不支持移除操作
        RoleComponent studentRole = new StudentRole();
        RoleComponent teacherRole = new TeacherRole();
        studentRole.remove(teacherRole); // 应该抛出异常
    }
    
    @Test(expected = UnsupportedOperationException.class)
    public void testLeafGetChildOperation() {
        // 测试叶子节点不支持获取子节点操作
        RoleComponent studentRole = new StudentRole();
        studentRole.getChild(0); // 应该抛出异常
    }
    
    @Test
    public void testNestedCompositeRoles() {
        // 测试嵌套组合角色
        // 创建顶层组合角色
        CompositeRole systemRoles = new CompositeRole("systemRoles", "系统角色");
        
        // 创建教师相关角色组合
        CompositeRole teacherRelatedRoles = new CompositeRole("teacherRoles", "教师相关角色");
        teacherRelatedRoles.add(new TeacherRole());
        teacherRelatedRoles.add(new StudentRole()); // 教师也可以查看学生内容
        
        // 创建管理员相关角色组合
        CompositeRole adminRelatedRoles = new CompositeRole("adminRoles", "管理员相关角色");
        adminRelatedRoles.add(new AdminRole());
        adminRelatedRoles.add(new TeacherRole()); // 管理员也可以执行教师权限
        
        // 将子组合角色添加到顶层组合角色
        systemRoles.add(teacherRelatedRoles);
        systemRoles.add(adminRelatedRoles);
        
        // 验证嵌套结构
        assertEquals("Top composite should have 2 children", 2, systemRoles.getChildCount());
        assertTrue("Child 0 should be composite", systemRoles.getChild(0).isComposite());
        assertTrue("Child 1 should be composite", systemRoles.getChild(1).isComposite());
        
        // 测试执行嵌套组合角色的权限
        systemRoles.executePermission();
    }
}