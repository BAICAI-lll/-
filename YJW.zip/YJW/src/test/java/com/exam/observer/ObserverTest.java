package com.exam.observer;

import org.junit.Test;
import static org.junit.Assert.*;

// 观察者模式测试
public class ObserverTest {
    
    @Test
    public void testNotificationCenterSingleton() {
        // 测试通知中心的单例模式
        NotificationCenter center1 = NotificationCenter.getInstance();
        NotificationCenter center2 = NotificationCenter.getInstance();
        
        assertSame("NotificationCenter should be a singleton", center1, center2);
        assertNotNull("NotificationCenter instance should not be null", center1);
    }
    
    @Test
    public void testObserverRegistration() {
        // 测试观察者注册和通知
        NotificationCenter center = NotificationCenter.getInstance();
        TestObserver observer = new TestObserver();
        
        // 注册观察者
        center.registerObserver(observer);
        
        // 发送通知
        String testMessage = "Test notification message";
        center.notifyObservers(testMessage);
        
        // 验证观察者收到通知
        assertTrue("Observer should have received notification", observer.isNotified());
        assertEquals("Observer should have received correct message", testMessage, observer.getMessage());
        
        // 移除观察者
        center.removeObserver(observer);
        
        // 重置观察者状态
        observer.reset();
        
        // 再次发送通知，验证观察者不再收到
        center.notifyObservers("Another test message");
        assertFalse("Observer should not have received notification after removal", observer.isNotified());
    }
    
    @Test
    public void testStaticNotificationMethod() {
        // 测试静态通知方法
        TestObserver observer = new TestObserver();
        NotificationCenter center = NotificationCenter.getInstance();
        center.registerObserver(observer);
        
        String testMessage = "Test static notification";
        NotificationCenter.sendNotification(testMessage);
        
        assertTrue("Observer should have received static notification", observer.isNotified());
        assertEquals("Observer should have received correct static message", testMessage, observer.getMessage());
        
        center.removeObserver(observer);
    }
    
    // 测试用的观察者实现
    private class TestObserver implements Observer {
        private boolean notified = false;
        private String message = "";
        
        @Override
        public void update(String message) {
            this.notified = true;
            this.message = message;
        }
        
        public boolean isNotified() {
            return notified;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void reset() {
            this.notified = false;
            this.message = "";
        }
    }
}