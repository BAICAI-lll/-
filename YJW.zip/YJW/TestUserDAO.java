import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.exam.util.DBUtil;
import com.exam.dao.UserDAO;

public class TestUserDAO {
    public static void main(String[] args) {
        // 测试UserDAO的getAllUsers方法
        UserDAO userDAO = new UserDAO();
        java.util.List<com.exam.model.User> users = userDAO.getAllUsers();
        
        System.out.println("UserDAO.getAllUsers() 测试结果:");
        System.out.println("用户名\t密码\t角色");
        for (com.exam.model.User user : users) {
            System.out.println(user.getUsername() + "\t" + user.getPassword() + "\t" + user.getRole());
        }
        
        System.out.println("\n测试完成，共获取到 " + users.size() + " 个用户");
    }
}