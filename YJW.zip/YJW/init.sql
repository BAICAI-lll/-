-- 删除现有数据库
DROP DATABASE IF EXISTS exam_system;

-- 创建数据库
CREATE DATABASE IF NOT EXISTS exam_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE exam_system;

-- 设置默认字符集
SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;
SET collation_connection = utf8mb4_unicode_ci;

-- 创建用户表
CREATE TABLE IF NOT EXISTS users (
    username VARCHAR(20) PRIMARY KEY,
    password VARCHAR(20) NOT NULL,
    role VARCHAR(10) NOT NULL, -- admin, teacher, student
    user_id VARCHAR(20) DEFAULT '', -- 关联教师或学生ID
    class_course_id VARCHAR(20) DEFAULT '' -- 班级或课程ID
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 创建教师表
CREATE TABLE IF NOT EXISTS teachers (
    teacher_id VARCHAR(10) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    gender VARCHAR(2) NOT NULL,
    phone VARCHAR(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 创建学生表
CREATE TABLE IF NOT EXISTS students (
    student_id VARCHAR(10) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    gender VARCHAR(2) NOT NULL,
    class_name VARCHAR(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 创建班级表
CREATE TABLE IF NOT EXISTS classes (
    class_id VARCHAR(10) PRIMARY KEY,
    class_name VARCHAR(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 创建课程表
CREATE TABLE IF NOT EXISTS courses (
    course_id VARCHAR(10) PRIMARY KEY,
    course_name VARCHAR(30) NOT NULL,
    teacher_id VARCHAR(10) NOT NULL,
    FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 创建题库表
CREATE TABLE IF NOT EXISTS questions (
    question_id INT AUTO_INCREMENT PRIMARY KEY,
    course_id VARCHAR(10) NOT NULL,
    question_content TEXT NOT NULL,
    option_a VARCHAR(100) NOT NULL,
    option_b VARCHAR(100) NOT NULL,
    option_c VARCHAR(100) NOT NULL,
    option_d VARCHAR(100) NOT NULL,
    correct_answer VARCHAR(2) NOT NULL,
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 创建成绩表
CREATE TABLE IF NOT EXISTS scores (
    student_id VARCHAR(10) NOT NULL,
    course_id VARCHAR(10) NOT NULL,
    score DOUBLE NOT NULL,
    exam_status VARCHAR(20) DEFAULT 'not_started',
    exam_count INT DEFAULT 0,
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 创建学生-课程关联表（用于课程选择）
CREATE TABLE IF NOT EXISTS student_courses (
    student_id VARCHAR(10) NOT NULL,
    course_id VARCHAR(10) NOT NULL,
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 插入初始数据

-- 插入用户数据 (用户名: 密码: 角色: user_id: class_course_id)
INSERT INTO users VALUES
('admin', 'admin123', 'admin', 'admin', ''),
('teacher1', 'teacher123', 'teacher', 'teacher001', 'course001'),
('student1', 'student123', 'student', 'student001', 'class001');

-- 插入班级数据
INSERT INTO classes VALUES
('class001', '软件1班'),
('class002', '软件2班');

-- 插入教师数据
INSERT INTO teachers VALUES
('teacher001', '张老师', '男', '13800138001'),
('teacher002', '李老师', '女', '13800138002');

-- 插入学生数据
INSERT INTO students VALUES
('student001', '张三', '男', '软件1班'),
('student002', '李四', '女', '软件1班'),
('student003', '王五', '男', '软件2班'),
('student004', '赵六', '女', '软件2班');

-- 插入课程数据
INSERT INTO courses VALUES
('course001', 'Java程序设计', 'teacher001'),
('course002', '数据库原理', 'teacher002');

-- 插入题库数据
INSERT INTO questions (course_id, question_content, option_a, option_b, option_c, option_d, correct_answer) VALUES
-- Java程序设计 (course001) 5道题
('course001', 'Java中用于定义类的关键字是？', 'class', 'interface', 'extends', 'implements', 'A'),
('course001', 'Java中用于继承的关键字是？', 'class', 'interface', 'extends', 'implements', 'C'),
('course001', 'Java中用于声明接口的关键字是？', 'class', 'interface', 'extends', 'implements', 'B'),
('course001', 'Java中用于实现接口的关键字是？', 'class', 'interface', 'extends', 'implements', 'D'),
('course001', 'Java中用于定义方法的关键字是？', 'void', 'return', 'public', 'static', 'C'),
-- 数据库原理 (course002) 5道题
('course002', 'SQL中用于查询数据的关键字是？', 'INSERT', 'UPDATE', 'DELETE', 'SELECT', 'D'),
('course002', 'SQL中用于插入数据的关键字是？', 'INSERT', 'UPDATE', 'DELETE', 'SELECT', 'A'),
('course002', 'SQL中用于更新数据的关键字是？', 'INSERT', 'UPDATE', 'DELETE', 'SELECT', 'B'),
('course002', 'SQL中用于删除数据的关键字是？', 'INSERT', 'UPDATE', 'DELETE', 'SELECT', 'C'),
('course002', 'SQL中用于创建表的关键字是？', 'CREATE', 'ALTER', 'DROP', 'TRUNCATE', 'A');

-- 插入成绩数据
INSERT INTO scores VALUES
('student001', 'course001', 85.5, 'completed', 1),
('student001', 'course002', 90.0, 'completed', 1),
('student002', 'course001', 78.5, 'completed', 1),
('student002', 'course002', 82.0, 'completed', 1);

-- 授权用户访问数据库（MySQL 8.0+语法）
FLUSH PRIVILEGES;