import com.exam.dao.UserDAO;
import com.exam.model.User;

public class TestAddUser {
    public static void main(String[] args) {
        // 测试添加用户功能
        UserDAO userDAO = new UserDAO();
        
        // 创建测试用户，包含user_id和class_course_id字段
        User testUser = new User("testuser", "test123", "student", "student005", "class002");
        
        // 测试添加用户
        System.out.println("测试添加用户：");
        boolean addResult = userDAO.addUser(testUser);
        System.out.println("添加结果：" + (addResult ? "成功" : "失败"));
        
        // 查询所有用户，验证添加是否成功
        System.out.println("\n添加后用户列表：");
        System.out.println("用户名\t密码\t角色\t用户ID\t班级/课程ID");
        for (User user : userDAO.getAllUsers()) {
            System.out.println(user.getUsername() + "\t" + user.getPassword() + "\t" + user.getRole() + "\t" + user.getUserId() + "\t" + user.getClassCourseId());
        }
        
        // 测试更新用户，包括user_id和class_course_id字段
        System.out.println("\n测试更新用户：");
        testUser.setPassword("updated123");
        testUser.setUserId("student006");
        testUser.setClassCourseId("class001");
        boolean updateResult = userDAO.updateUser(testUser);
        System.out.println("更新结果：" + (updateResult ? "成功" : "失败"));
        
        // 查询所有用户，验证更新是否成功
        System.out.println("\n更新后用户列表：");
        System.out.println("用户名\t密码\t角色\t用户ID\t班级/课程ID");
        for (User user : userDAO.getAllUsers()) {
            System.out.println(user.getUsername() + "\t" + user.getPassword() + "\t" + user.getRole() + "\t" + user.getUserId() + "\t" + user.getClassCourseId());
        }
        
        // 测试删除用户
        System.out.println("\n测试删除用户：");
        boolean deleteResult = userDAO.deleteUser("testuser");
        System.out.println("删除结果：" + (deleteResult ? "成功" : "失败"));
        
        // 查询所有用户，验证删除是否成功
        System.out.println("\n删除后用户列表：");
        System.out.println("用户名\t密码\t角色\t用户ID\t班级/课程ID");
        for (User user : userDAO.getAllUsers()) {
            System.out.println(user.getUsername() + "\t" + user.getPassword() + "\t" + user.getRole() + "\t" + user.getUserId() + "\t" + user.getClassCourseId());
        }
    }
}