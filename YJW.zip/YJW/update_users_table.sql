-- 更新users表结构，添加缺少的字段
USE exam_system;

-- 1. 添加user_id字段
ALTER TABLE users 
ADD COLUMN user_id VARCHAR(20) DEFAULT '' AFTER role;

-- 2. 添加class_course_id字段
ALTER TABLE users 
ADD COLUMN class_course_id VARCHAR(20) DEFAULT '' AFTER user_id;

-- 3. 查看更新后的表结构
DESCRIBE users;

-- 4. 更新现有数据的user_id字段
UPDATE users SET 
    user_id = CASE 
        WHEN username = 'admin' THEN 'admin' 
        WHEN username = 'teacher1' THEN 'teacher001' 
        WHEN username = 'student1' THEN 'student001' 
        ELSE '' 
    END;

-- 5. 更新现有数据的class_course_id字段
UPDATE users SET 
    class_course_id = CASE 
        WHEN role = 'teacher' THEN 'course001' 
        WHEN role = 'student' THEN 'class001' 
        ELSE '' 
    END;

-- 6. 查看更新后的数据
SELECT * FROM users;
