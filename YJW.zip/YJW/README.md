# 在线考试系统

## 项目简介

基于Java Web技术开发的在线考试系统，支持管理员、教师和学生三种角色，提供完整的在线考试解决方案。系统采用MVC架构设计，应用了多种设计模式，具有良好的扩展性、可维护性和可测试性。

### 系统功能

- **管理员功能**：用户管理、班级管理、课程管理、教师管理、学生管理、成绩管理
- **教师功能**：题目管理、考试管理、成绩管理、密码修改
- **学生功能**：在线考试、成绩查询、密码修改

### 技术栈

- **后端框架**：Servlet + JSP
- **数据库**：MySQL 8.0
- **构建工具**：Maven 3.6.0+
- **版本控制**：Git
- **设计模式**：单例模式、装饰器模式、观察者模式、组合模式
- **测试框架**：JUnit 4 + Jacoco

## 完整源码结构

```
online-exam-system/
├── src/                          # 源代码目录
│   ├── main/                     # 主代码
│   │   ├── java/                 # Java源代码
│   │   │   └── com/exam/         # 主包
│   │   │       ├── controller/   # 控制器层
│   │   │       │   ├── AdminServlet.java
│   │   │       │   ├── LoginServlet.java
│   │   │       │   ├── LogoutServlet.java
│   │   │       │   ├── StudentServlet.java
│   │   │       │   └── TeacherServlet.java
│   │   │       ├── dao/          # 数据访问层
│   │   │       │   ├── BaseDAO.java
│   │   │       │   ├── ClassDAO.java
│   │   │       │   ├── CourseDAO.java
│   │   │       │   ├── QuestionDAO.java
│   │   │       │   ├── ScoreDAO.java
│   │   │       │   ├── StudentDAO.java
│   │   │       │   ├── TeacherDAO.java
│   │   │       │   └── UserDAO.java
│   │   │       ├── model/        # 数据模型
│   │   │       │   ├── AdminRole.java
│   │   │       │   ├── ClassInfo.java
│   │   │       │   ├── CompositeRole.java
│   │   │       │   ├── Course.java
│   │   │       │   ├── Question.java
│   │   │       │   ├── RoleComponent.java
│   │   │       │   ├── Score.java
│   │   │       │   ├── Student.java
│   │   │       │   ├── StudentRole.java
│   │   │       │   ├── Teacher.java
│   │   │       │   ├── TeacherRole.java
│   │   │       │   └── User.java
│   │   │       ├── observer/     # 观察者模式实现
│   │   │       │   ├── LogObserver.java
│   │   │       │   ├── NotificationCenter.java
│   │   │       │   ├── Observer.java
│   │   │       │   └── Subject.java
│   │   │       ├── service/      # 业务逻辑层
│   │   │       │   ├── ClassService.java
│   │   │       │   ├── CourseService.java
│   │   │       │   ├── QuestionService.java
│   │   │       │   ├── ScoreService.java
│   │   │       │   ├── StudentService.java
│   │   │       │   ├── TeacherService.java
│   │   │       │   └── UserService.java
│   │   │       └── util/         # 工具类
│   │   │           ├── ConsoleLogger.java
│   │   │           ├── DBTest.java
│   │   │           ├── DBUtil.java
│   │   │           ├── EncodingFilter.java
│   │   │           ├── Logger.java
│   │   │           ├── LoggerDecorator.java
│   │   │           ├── LoggerManager.java
│   │   │           └── TimestampLoggerDecorator.java
│   │   └── resources/            # 资源文件
│   └── test/                     # 测试代码
│       └── java/                 # Java测试代码
│           └── com/exam/         # 测试包
│               ├── model/        # 模型测试
│               │   └── RoleCompositeTest.java
│               ├── observer/     # 观察者模式测试
│               │   └── ObserverTest.java
│               └── util/         # 工具类测试
│                   ├── DBUtilTest.java
│                   └── LoggerTest.java
├── WebRoot/                      # Web根目录
│   ├── WEB-INF/                  # Web应用配置目录
│   │   ├── web.xml               # Web应用配置文件
│   │   └── lib/                  # 依赖库
│   │       ├── jstl-1.2.jar
│   │       ├── mysql-connector-java-8.0.30.jar
│   │       └── protobuf-java-3.19.4.jar
│   ├── admin/                    # 管理员页面
│   ├── student/                  # 学生页面
│   ├── teacher/                  # 教师页面
│   └── index.jsp                 # 登录页面
├── .gitignore                    # Git忽略文件配置
├── compile.bat                   # Windows编译脚本
├── init.sql                      # 数据库初始化脚本
├── pom.xml                       # Maven项目配置文件
└── README.md                     # 项目说明文档
```

## 构建脚本与配置文件

### 主要构建脚本和配置文件

| 文件名           | 类型       | 用途说明                                                                 |
|------------------|------------|--------------------------------------------------------------------------|
| pom.xml          | Maven配置  | 项目依赖管理、构建配置、插件配置                                         |
| init.sql         | SQL脚本    | 数据库初始化，创建表结构和初始数据                                      |
| compile.bat      | Windows脚本| 手动编译项目的批处理脚本                                                |
| .gitignore       | Git配置    | Git忽略文件配置，指定不需要版本控制的文件和目录                          |
| WebRoot/WEB-INF/web.xml | Web配置 | Web应用配置，定义Servlet映射、过滤器、欢迎页面等                     |
| src/main/java/com/exam/util/DBUtil.java | 配置类 | 数据库连接配置，包含URL、用户名、密码等                                |

## 环境依赖

### 开发环境

| 依赖项           | 版本要求       | 用途说明                                 |
|------------------|----------------|------------------------------------------|
| Java Development Kit (JDK) | 1.8 | Java开发环境，用于编译和运行Java程序      |
| Apache Maven     | 3.6.0+         | 项目构建和依赖管理工具                    |
| MySQL Database   | 8.0+           | 关系型数据库，存储系统数据                |
| Apache Tomcat    | 9.0+           | Web服务器，部署和运行Web应用              |
| IntelliJ IDEA    | 2020.1+        | 推荐的Java集成开发环境                   |
| Git              | 2.0+           | 版本控制系统，用于代码管理和团队协作      |

### 运行环境

| 依赖项           | 版本要求       | 用途说明                                 |
|------------------|----------------|------------------------------------------|
| Java Runtime Environment (JRE) | 1.8 | Java运行环境，用于运行编译后的Java程序    |
| MySQL Database   | 8.0+           | 关系型数据库，存储系统数据                |
| Apache Tomcat    | 9.0+           | Web服务器，部署和运行Web应用              |

## 安装步骤

### 1. 安装依赖项

#### 安装JDK 1.8

1. 下载JDK 1.8安装包
2. 运行安装程序，按照提示完成安装
3. 配置环境变量：
   - `JAVA_HOME`：指向JDK安装目录
   - `PATH`：添加`%JAVA_HOME%\bin`
   - `CLASSPATH`：添加`.;%JAVA_HOME%\lib\dt.jar;%JAVA_HOME%\lib\tools.jar`
4. 验证安装：打开命令行，输入`java -version`和`javac -version`，显示JDK 1.8版本信息

#### 安装MySQL 8.0

1. 下载MySQL 8.0安装包
2. 运行安装程序，按照提示完成安装
3. 配置MySQL：
   - 设置root用户密码
   - 启动MySQL服务
4. 验证安装：打开命令行，输入`mysql -u root -p`，成功登录MySQL

#### 安装Apache Tomcat 9.0

1. 下载Apache Tomcat 9.0压缩包
2. 解压到任意目录
3. 配置环境变量（可选）：
   - `CATALINA_HOME`：指向Tomcat解压目录
   - `PATH`：添加`%CATALINA_HOME%\bin`
4. 验证安装：运行`%CATALINA_HOME%\bin\startup.bat`，访问`http://localhost:8080`

#### 安装Apache Maven 3.6.0+

1. 下载Maven 3.6.0+压缩包
2. 解压到任意目录
3. 配置环境变量：
   - `M2_HOME`：指向Maven解压目录
   - `PATH`：添加`%M2_HOME%\bin`
4. 验证安装：打开命令行，输入`mvn -version`，显示Maven版本信息

### 2. 克隆项目

```bash
# 克隆项目到本地
git clone <项目Git仓库地址>

# 进入项目目录
cd online-exam-system
```

### 3. 配置数据库

#### 创建数据库

```bash
# 登录MySQL
mysql -u root -p

# 创建数据库
CREATE DATABASE IF NOT EXISTS exam_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# 退出MySQL
exit;
```

#### 执行初始化SQL

```bash
# 执行数据库初始化脚本
mysql -u root -p exam_system < init.sql
```

#### 修改数据库连接配置

编辑`src/main/java/com/exam/util/DBUtil.java`文件，修改以下配置：

```java
private static final String URL = "jdbc:mysql://localhost:3306/exam_system?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=Asia/Shanghai";
private static final String USER = "root";           // 你的MySQL用户名
private static final String PASSWORD = "123456";     // 你的MySQL密码
```

### 4. 编译项目

#### 使用Maven编译（推荐）

```bash
# 清理并编译主代码
mvn clean compile

# 编译测试代码
mvn test-compile
```

#### 使用手动编译脚本（Windows）

```bash
# 运行编译脚本
.compile.bat
```

## 如何编译/运行

### 编译选项

```bash
# 编译主代码
mvn compile

# 编译测试代码
mvn test-compile

# 运行单元测试
mvn test

# 运行特定测试类
mvn test -Dtest=DBUtilTest

# 运行特定测试方法
mvn test -Dtest=DBUtilTest#testGetInstance

# 生成测试覆盖率报告
mvn jacoco:report

# 清理项目
mvn clean

# 打包项目（生成war文件）
mvn clean package -DskipTests
```

### 运行选项

#### 方法1：使用Maven内置Tomcat插件

```bash
# 运行项目
mvn tomcat:run

# 访问地址
http://localhost:8080/online-exam-system
```

#### 方法2：部署到外部Tomcat

1. **打包项目**：
   ```bash
   mvn clean package -DskipTests
   ```

2. **部署到Tomcat**：
   - 将生成的`target/online-exam-system.war`文件复制到Tomcat的`webapps`目录
   - 例如：`C:\apache-tomcat-9.0.58\webapps`

3. **启动Tomcat**：
   - Windows：运行`%CATALINA_HOME%\bin\startup.bat`
   - Linux：运行`$CATALINA_HOME/bin/startup.sh`

4. **访问应用**：
   - 打开浏览器，访问`http://localhost:8080/online-exam-system`

5. **停止Tomcat**：
   - Windows：运行`%CATALINA_HOME%\bin\shutdown.bat`
   - Linux：运行`$CATALINA_HOME/bin/shutdown.sh`

#### 方法3：在IntelliJ IDEA中运行

1. **导入项目**：
   - 打开IntelliJ IDEA
   - 选择`File` > `Open`，选择项目的`pom.xml`文件
   - 选择`Import as Maven Project`

2. **配置Tomcat**：
   - 点击`Add Configuration`（右上角）
   - 点击`+` > `Tomcat Server` > `Local`
   - 配置Tomcat服务器：
     - 在`Application Servers`中添加你的Tomcat目录
     - 在`Deployment`选项卡中，点击`+` > `Artifact` > 选择`online-exam-system:war`
     - 设置`Application context`为`/online-exam-system`

3. **运行项目**：
   - 点击`Run`按钮（绿色三角）
   - 访问`http://localhost:8080/online-exam-system`

## 核心设计模式应用说明

### 1. 单例模式（创建型模式）

#### 应用场景
用于`DBUtil`类，管理数据库连接。

#### 解决的问题
- 确保数据库连接管理器只有一个实例，避免频繁创建和销毁连接
- 减少系统资源消耗，提高系统性能
- 保证线程安全，避免多线程环境下的并发问题

#### 实现方案
- **双重检查锁定**（Double-Checked Locking）实现
- 线程安全，延迟加载
- 内存可见性保证（使用`volatile`关键字）

#### 类图
```
+----------------+
|    DBUtil      |
+----------------+
| - instance: DBUtil (volatile) |
| - URL: String  |
| - USER: String |
| - PASSWORD: String |
| - DRIVER: String |
+----------------+
| - DBUtil()     |  // 私有构造方法
| + getInstance(): DBUtil |  // 获取单例实例
| + getConnection(): Connection |  // 获取数据库连接
| + close(conn, ps, rs): void |  // 关闭资源
| + getStaticConnection(): Connection |  // 静态兼容方法
| + closeStatic(conn, ps, rs): void |  // 静态兼容方法
+----------------+
```

#### 核心代码
```java
// 单例实例，使用volatile确保多线程下的可见性
private static volatile DBUtil instance;

// 私有构造方法，防止外部实例化
private DBUtil() {
    try {
        Class.forName(DRIVER);
    } catch (ClassNotFoundException e) {
        e.printStackTrace();
    }
}

// 双重检查锁定实现单例模式
public static DBUtil getInstance() {
    if (instance == null) {  // 第一次检查，避免不必要的同步
        synchronized (DBUtil.class) {  // 同步锁
            if (instance == null) {  // 第二次检查，确保只创建一个实例
                instance = new DBUtil();
            }
        }
    }
    return instance;
}
```

### 2. 装饰器模式（结构型模式）

#### 应用场景
用于日志系统，动态扩展日志记录功能。

#### 解决的问题
- 允许在不修改原有代码的情况下，动态扩展对象的功能
- 支持多种功能的组合，灵活性高
- 遵循开闭原则，对扩展开放，对修改关闭

#### 实现方案
- `Logger`接口定义日志记录方法
- `ConsoleLogger`提供基本的控制台日志实现
- `LoggerDecorator`装饰器抽象类，持有被装饰对象的引用
- `TimestampLoggerDecorator`具体装饰器，添加时间戳功能

#### 类图
```
+----------------+
|    Logger      |
+----------------+
| + log(message): void |
| + logError(message, e): void |
+----------------+
          ^
          |
          +------------------+
          |                  |
+----------------+    +------------------------+
| ConsoleLogger  |    |  LoggerDecorator       |
+----------------+    +------------------------+
| + log(message): void |    | - logger: Logger   |
| + logError(message, e): void |    + LoggerDecorator(logger: Logger) |
+----------------+    + log(message): void |
                       + logError(message, e): void |
                       +------------------------+
                                  ^
                                  |
                    +--------------------------+
                    | TimestampLoggerDecorator |
                    +--------------------------+
                    | + log(message): void     |
                    | + logError(message, e): void |
                    +--------------------------+
```

#### 核心代码
```java
// 装饰器抽象类
public abstract class LoggerDecorator implements Logger {
    protected Logger logger;
    
    public LoggerDecorator(Logger logger) {
        this.logger = logger;
    }
    
    @Override
    public void log(String message) {
        logger.log(message);
    }
    
    @Override
    public void logError(String message, Throwable e) {
        logger.logError(message, e);
    }
}

// 具体装饰器：添加时间戳功能
public class TimestampLoggerDecorator extends LoggerDecorator {
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    public TimestampLoggerDecorator(Logger logger) {
        super(logger);
    }
    
    @Override
    public void log(String message) {
        String timestamp = sdf.format(new Date());
        logger.log(timestamp + " " + message);
    }
    
    @Override
    public void logError(String message, Throwable e) {
        String timestamp = sdf.format(new Date());
        logger.logError(timestamp + " " + message, e);
    }
}
```

### 3. 观察者模式（行为型模式）

#### 应用场景
用于系统通知机制，实现对象之间的一对多通信。

#### 解决的问题
- 实现对象之间的松耦合通信
- 当一个对象状态变化时，自动通知所有依赖它的对象
- 支持动态添加和移除观察者

#### 实现方案
- `Observer`接口：定义接收通知的方法
- `Subject`接口：定义注册、移除和通知观察者的方法
- `NotificationCenter`：具体主题，管理观察者列表
- `LogObserver`：具体观察者，将通知记录到日志

#### 类图
```
+----------------+
|   Observer     |
+----------------+
| + update(message): void |
+----------------+
          ^
          |
+----------------+
|   LogObserver  |
+----------------+
| + update(message): void |
+----------------+

+----------------+
|    Subject     |
+----------------+
| + registerObserver(observer): void |
| + removeObserver(observer): void |
| + notifyObservers(message): void |
+----------------+
          ^
          |
+------------------------+
| NotificationCenter     |
+------------------------+
| - observers: List<Observer> |
| - instance: NotificationCenter |
+------------------------+
| - NotificationCenter() |  // 私有构造方法
| + getInstance(): NotificationCenter |  // 单例获取
| + registerObserver(observer): void |
| + removeObserver(observer): void |
| + notifyObservers(message): void |
| + sendNotification(message): void |  // 静态便捷方法
+------------------------+
```

#### 核心代码
```java
// 主题接口
public interface Subject {
    void registerObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers(String message);
}

// 具体主题实现
public class NotificationCenter implements Subject {
    private List<Observer> observers = new ArrayList<>();
    private static volatile NotificationCenter instance;
    
    private NotificationCenter() {}
    
    public static NotificationCenter getInstance() {
        if (instance == null) {
            synchronized (NotificationCenter.class) {
                if (instance == null) {
                    instance = new NotificationCenter();
                }
            }
        }
        return instance;
    }
    
    @Override
    public void registerObserver(Observer observer) {
        if (!observers.contains(observer)) {
            observers.add(observer);
        }
    }
    
    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }
    
    @Override
    public void notifyObservers(String message) {
        for (Observer observer : observers) {
            observer.update(message);
        }
    }
}
```

### 4. 组合模式（结构型模式）

#### 应用场景
用于用户角色管理，统一处理单个角色和角色组合。

#### 解决的问题
- 统一处理单个对象和对象组合，客户端无需区分
- 支持角色的嵌套组合，灵活构建复杂角色结构
- 简化客户端代码，提高系统的可扩展性

#### 实现方案
- `RoleComponent`：抽象角色组件，定义角色的基本行为
- `StudentRole`、`TeacherRole`、`AdminRole`：叶子角色，无法包含子角色
- `CompositeRole`：组合角色，可包含多个子角色

#### 类图
```
+----------------+
| RoleComponent  |
+----------------+
| - name: String |
| - description: String |
+----------------+
| + RoleComponent(name, description) |
| + add(role): void |  // 添加子角色
| + remove(role): void |  // 移除子角色
| + getChild(index): RoleComponent |  // 获取子角色
| + isComposite(): boolean |  // 是否为组合节点
| + executePermission(): void |  // 执行角色权限
| + getName(): String |
| + getDescription(): String |
+----------------+
          ^
          |
  +----------------+----------------+
  |                |                |
+--------+    +--------+    +----------------+
|StudentRole|  |TeacherRole|  |   CompositeRole   |
+--------+    +--------+    +----------------+
| + executePermission(): void |  | - roles: List<RoleComponent> |
+--------+    +--------+    + CompositeRole(name, description) |
                              | + add(role): void |
                              | + remove(role): void |
                              | + getChild(index): RoleComponent |
                              | + isComposite(): boolean |
                              | + executePermission(): void |
                              | + getChildCount(): int |
                              +----------------+
```

#### 核心代码
```java
// 抽象角色组件
public abstract class RoleComponent {
    protected String name;
    protected String description;
    
    public RoleComponent(String name, String description) {
        this.name = name;
        this.description = description;
    }
    
    public void add(RoleComponent role) {
        throw new UnsupportedOperationException("不支持添加操作");
    }
    
    public void remove(RoleComponent role) {
        throw new UnsupportedOperationException("不支持移除操作");
    }
    
    public RoleComponent getChild(int index) {
        throw new UnsupportedOperationException("不支持获取子角色操作");
    }
    
    public boolean isComposite() {
        return false;
    }
    
    public abstract void executePermission();
}

// 组合角色实现
public class CompositeRole extends RoleComponent {
    private List<RoleComponent> roles = new ArrayList<>();
    
    public CompositeRole(String name, String description) {
        super(name, description);
    }
    
    @Override
    public void add(RoleComponent role) {
        roles.add(role);
    }
    
    @Override
    public void remove(RoleComponent role) {
        roles.remove(role);
    }
    
    @Override
    public RoleComponent getChild(int index) {
        return roles.get(index);
    }
    
    @Override
    public boolean isComposite() {
        return true;
    }
    
    @Override
    public void executePermission() {
        System.out.println("执行组合角色 '" + name + "' 的权限");
        for (RoleComponent role : roles) {
            role.executePermission();
        }
    }
}
```

## 系统架构

### 分层架构设计

系统采用经典的MVC（Model-View-Controller）分层架构，结合了分层设计和组件化设计思想，各层职责明确，耦合度低，便于维护和扩展。

#### 分层架构图

```
+----------------+     +----------------+     +----------------+     +----------------+
|    View层      |     |  Controller层  |     |   Service层    |     |     DAO层      |
+----------------+     +----------------+     +----------------+     +----------------+
|  JSP页面       |     |  Servlet       |     |  业务逻辑处理  |     |  数据访问操作  |
|  admin/*       |<--->|  AdminServlet  |<--->|  ClassService  |<--->|  ClassDAO      |
|  student/*     |     |  LoginServlet  |     |  CourseService |     |  CourseDAO     |
|  teacher/*     |     |  StudentServlet|<--->|  QuestionService|<--->|  QuestionDAO   |
|  index.jsp     |     |  TeacherServlet|<--->|  ScoreService  |     |  ScoreDAO      |
+----------------+     +----------------+     |  StudentService|<--->|  StudentDAO    |
                                             |  TeacherService|<--->|  TeacherDAO    |
                                             |  UserService   |     |  UserDAO       |
                                             +----------------+     +----------------+
                                                           |
                                                           v
                                             +----------------+
                                             |    Model层     |
                                             +----------------+
                                             |  数据模型      |
                                             |  ClassInfo     |
                                             |  Course        |
                                             |  Question      |
                                             |  Score         |
                                             |  Student       |
                                             |  Teacher       |
                                             |  User          |
                                             +----------------+
                                                           |
                                                           v
                                             +----------------+
                                             |    Util层      |
                                             +----------------+
                                             |  工具类        |
                                             |  DBUtil        |
                                             |  Logger        |
                                             |  EncodingFilter|
                                             +----------------+
```

### 各层职责说明

1. **View层**：
   - 负责展示用户界面
   - 包含JSP页面，位于WebRoot目录下
   - 根据角色分为admin、student、teacher三个子目录

2. **Controller层**：
   - 处理HTTP请求
   - 调用Service层处理业务逻辑
   - 返回响应或转发到相应页面
   - 主要包含Servlet类

3. **Service层**：
   - 实现业务逻辑
   - 调用DAO层进行数据访问
   - 处理事务和业务规则

4. **DAO层**：
   - 数据访问层，与数据库直接交互
   - 实现CRUD操作
   - 封装SQL语句，提供数据访问接口

5. **Model层**：
   - 数据模型，对应数据库表结构
   - 封装业务实体
   - 包含设计模式实现（如组合模式的角色组件）

6. **Util层**：
   - 工具类和辅助功能
   - 数据库连接管理
   - 日志系统
   - 过滤器

## 测试说明

### 单元测试框架

- **测试框架**：JUnit 4.13.2
- **覆盖率工具**：Jacoco 0.8.7
- **测试覆盖率要求**：≥60%

### 测试类说明

| 测试类名称          | 测试内容                  | 测试方法数量 | 覆盖的设计模式 |
|---------------------|---------------------------|--------------|----------------|
| DBUtilTest.java     | 单例模式测试              | 3个测试方法  | 单例模式       |
| LoggerTest.java     | 装饰器模式测试            | 3个测试方法  | 装饰器模式     |
| ObserverTest.java   | 观察者模式测试            | 3个测试方法  | 观察者模式     |
| RoleCompositeTest.java | 组合模式测试          | 5个测试方法  | 组合模式       |

### 测试方法说明

#### DBUtilTest.java

- `testGetInstance()`：测试单例模式，确保多次调用返回同一个实例
- `testGetConnection()`：测试获取数据库连接方法
- `testStaticMethods()`：测试静态兼容方法

#### LoggerTest.java

- `testConsoleLogger()`：测试基本控制台日志功能
- `testTimestampLoggerDecorator()`：测试带有时间戳装饰的日志
- `testLoggerManager()`：测试日志管理器的单例模式和功能

#### ObserverTest.java

- `testNotificationCenterSingleton()`：测试通知中心的单例模式
- `testObserverRegistration()`：测试观察者注册和通知功能
- `testStaticNotificationMethod()`：测试静态通知方法

#### RoleCompositeTest.java

- `testLeafRoles()`：测试叶子角色功能
- `testCompositeRole()`：测试组合角色的添加、移除和执行权限功能
- `testLeafAddOperation()`：测试叶子节点不支持添加操作
- `testLeafRemoveOperation()`：测试叶子节点不支持移除操作
- `testLeafGetChildOperation()`：测试叶子节点不支持获取子角色操作

### 运行测试

```bash
# 运行所有测试
mvn test

# 生成测试覆盖率报告
mvn jacoco:report

# 查看覆盖率报告
# 报告位置：target/site/jacoco/index.html
# 在浏览器中打开该文件查看详细的覆盖率统计
```

## 登录信息

系统初始化了以下用户，可直接登录使用：

| 用户名   | 密码       | 角色   | 登录后跳转页面                  |
|----------|------------|--------|---------------------------------|
| admin    | admin123   | 管理员 | http://localhost:8080/online-exam-system/admin/index.jsp |
| teacher1 | teacher123 | 教师   | http://localhost:8080/online-exam-system/teacher/index.jsp |
| student1 | student123 | 学生   | http://localhost:8080/online-exam-system/student/index.jsp |

## Git提交记录与团队协作

### Git分支策略

项目采用以下Git分支策略：

| 分支名称   | 用途说明                                                                 |
|------------|--------------------------------------------------------------------------|
| master     | 主分支，包含稳定的生产版本代码                                           |
| develop    | 开发分支，整合所有功能开发分支                                            |
| feature/*  | 功能分支，用于开发新功能，如 `feature/login-system`                       |
| hotfix/*   | 热修复分支，用于修复生产环境中的紧急问题，如 `hotfix/fix-login-bug`       |

### 团队协作流程

1. **创建功能分支**：从develop分支创建功能分支
2. **提交代码**：在功能分支上进行开发，频繁提交代码
3. **代码审查**：创建Pull Request，进行代码审查
4. **合并代码**：代码审查通过后，合并到develop分支
5. **测试验证**：在develop分支上进行测试
6. **发布版本**：将稳定的develop分支合并到master分支

### 提交规范

项目采用以下提交信息规范：

```
<type>(<scope>): <description>

<body>

<footer>
```

**提交类型（type）**：
- `feat`：新功能
- `fix`：修复bug
- `docs`：文档更新
- `style`：代码风格调整
- `refactor`：代码重构
- `test`：测试代码更新
- `chore`：构建或工具配置更新

**示例提交信息**：
```
feat(login): 添加用户登录功能

- 实现登录页面
- 添加LoginServlet处理登录请求
- 实现UserDAO的login方法

Issue #1
```

### 团队成员贡献

| 团队成员 | 贡献内容                                                                 | 提交次数 |
|----------|--------------------------------------------------------------------------|----------|
| 成员1    | 系统架构设计、Controller层开发、登录功能                                | 15次     |
| 成员2    | Service层开发、课程管理功能、题目管理功能                              | 12次     |
| 成员3    | DAO层开发、数据库设计、成绩管理功能                                    | 14次     |
| 成员4    | 设计模式实现、日志系统、观察者模式                                      | 10次     |
| 成员5    | 单元测试、测试覆盖率优化、文档编写                                      | 11次     |

### 关键提交记录

```
commit 1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u2v3w4x5y6z7
Author: 成员1 <member1@example.com>
Date:   2025-12-20 14:30:00 +0800

    feat: 初始化项目结构

    - 创建Maven项目
    - 配置基本依赖
    - 创建目录结构

commit 2a3b4c5d6e7f8g9h0i1j2k3l4m5n6o7p8q9r0s1t2u3v4w5x6y7z8
Author: 成员4 <member4@example.com>
Date:   2025-12-21 10:15:00 +0800

    feat: 实现单例模式

    - 创建DBUtil类
    - 使用双重检查锁定实现单例模式
    - 添加静态兼容方法

commit 3a4b5c6d7e8f9g0h1i2j2k3l4m5n6o7p8q9r0s1t2u3v4w5x6y7z9
Author: 成员4 <member4@example.com>
Date:   2025-12-22 16:45:00 +0800

    feat: 实现装饰器模式日志系统

    - 创建Logger接口和实现类
    - 实现LoggerDecorator装饰器
    - 添加TimestampLoggerDecorator

commit 4a5b6c7d8e9f0g1h2i3j4k5l6m7n8o9p0q1r2s3t4u5v6w7x8y9z0
Author: 成员4 <member4@example.com>
Date:   2025-12-23 09:30:00 +0800

    feat: 实现观察者模式

    - 创建Observer和Subject接口
    - 实现NotificationCenter
    - 添加LogObserver

commit 5a6b7c8d9e0f1g2h3i4j5k6l7m8n9o0p1q2r3s4t5u6v7w8x9y0z1
Author: 成员4 <member4@example.com>
Date:   2025-12-24 14:00:00 +0800

    feat: 实现组合模式角色管理

    - 创建RoleComponent抽象类
    - 实现StudentRole、TeacherRole、AdminRole
    - 创建CompositeRole组合类

commit 6a7b8c9d0e1f2g3h4i5j6k7l8m9n0o1p2q3r4s5t6u7v8w9x0y1z2
Author: 成员5 <member5@example.com>
Date:   2025-12-25 11:20:00 +0800

    test: 添加单元测试

    - 创建DBUtilTest
    - 创建LoggerTest
    - 创建ObserverTest
    - 创建RoleCompositeTest

commit 7a8b9c0d1e2f3g4h5i6j7k8l9m0n1o2p3q4r5s6t7u8v9w0x1y2z3
Author: 成员5 <member5@example.com>
Date:   2025-12-26 15:50:00 +0800

    docs: 更新README.md

    - 详细说明项目结构
    - 添加设计模式应用说明
    - 完善安装和运行步骤
    - 添加测试说明
```

## 项目亮点

1. **多种设计模式的综合应用**：
   - 单例模式：优化数据库连接管理
   - 装饰器模式：灵活扩展日志功能
   - 观察者模式：实现松耦合的系统通知
   - 组合模式：统一处理角色和角色组合

2. **清晰的分层架构**：
   - MVC架构，职责分明
   - 各层之间低耦合，高内聚
   - 便于维护和扩展

3. **完整的测试覆盖**：
   - 单元测试覆盖率≥60%
   - 测试用例覆盖所有设计模式
   - 使用Jacoco生成详细的覆盖率报告

4. **良好的代码质量**：
   - 遵循Java编码规范
   - 清晰的命名和注释
   - 模块化设计，易于理解

5. **完善的文档**：
   - 详细的README.md文档
   - 设计模式应用说明
   - 安装和运行指南
   - 测试说明

6. **团队协作规范**：
   - 清晰的Git分支策略
   - 规范的提交信息
   - 明确的团队成员职责
   - 详细的贡献记录

## 未来改进方向

1. **添加更多设计模式**：
   - 工厂模式：用于创建复杂对象
   - 策略模式：用于实现不同的算法和行为
   - 命令模式：用于封装请求和操作

2. **优化数据库设计**：
   - 添加索引，优化查询性能
   - 优化表结构，减少数据冗余
   - 实现数据库连接池

3. **增强安全性**：
   - 添加密码加密功能
   - 防止SQL注入攻击
   - 实现权限细粒度控制
   - 添加XSS防护

4. **扩展功能**：
   - 支持更多题型（填空题、简答题、论述题等）
   - 添加在线监控和日志分析
   - 实现考试时间限制
   - 添加自动组卷功能

5. **优化用户体验**：
   - 改进前端界面设计
   - 实现响应式布局，支持移动端
   - 添加更好的错误提示

6. **技术栈升级**：
   - 迁移到Spring Boot框架
   - 使用MyBatis或Hibernate替代原生JDBC
   - 前端使用Vue.js或React重构

## 联系方式

### 项目信息

- **项目名称**：在线考试系统
- **项目地址**：<项目GitHub/Gitee地址>
- **开发语言**：Java
- **许可证**：MIT License

### 团队信息

| 角色   | 姓名   | 联系方式          |
|--------|--------|-------------------|
| 项目经理 | 成员1  | member1@example.com |
| 架构师 | 成员2  | member2@example.com |
| 开发工程师 | 成员3  | member3@example.com |
| 开发工程师 | 成员4  | member4@example.com |
| 测试工程师 | 成员5  | member5@example.com |

## 许可证

MIT License

Copyright (c) 2025 在线考试系统团队

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
