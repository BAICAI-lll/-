import com.exam.service.ScoreService;
import com.exam.model.Score;

public class TestStudentScores {
    public static void main(String[] args) {
        // 测试学生成绩查询
        ScoreService scoreService = new ScoreService();
        
        // 测试使用student001作为学生ID
        String testStudentId = "student001";
        System.out.println("测试学生ID: " + testStudentId);
        
        // 查询成绩
        System.out.println("\n查询结果：");
        System.out.println("课程ID\t成绩\t考试状态\t考试次数");
        for (Score score : scoreService.getScoresByStudentId(testStudentId)) {
            System.out.println(
                score.getCourseId() + "\t" +
                score.getScore() + "\t" +
                score.getExamStatus() + "\t" +
                score.getExamCount()
            );
        }
        
        System.out.println("\n测试完成，共获取到 " + scoreService.getScoresByStudentId(testStudentId).size() + " 条成绩数据");
        
        // 测试使用student002作为学生ID
        String testStudentId2 = "student002";
        System.out.println("\n\n测试学生ID: " + testStudentId2);
        
        // 查询成绩
        System.out.println("\n查询结果：");
        System.out.println("课程ID\t成绩\t考试状态\t考试次数");
        for (Score score : scoreService.getScoresByStudentId(testStudentId2)) {
            System.out.println(
                score.getCourseId() + "\t" +
                score.getScore() + "\t" +
                score.getExamStatus() + "\t" +
                score.getExamCount()
            );
        }
        
        System.out.println("\n测试完成，共获取到 " + scoreService.getScoresByStudentId(testStudentId2).size() + " 条成绩数据");
    }
}