import com.exam.service.ScoreService;
import com.exam.model.Score;

public class TestScoreService {
    public static void main(String[] args) {
        // 测试成绩查询功能
        ScoreService scoreService = new ScoreService();
        
        System.out.println("测试ScoreService.getAllScores()方法：");
        System.out.println("学生ID\t课程ID\t成绩\t考试状态\t考试次数");
        
        for (Score score : scoreService.getAllScores()) {
            System.out.println(
                score.getStudentId() + "\t" +
                score.getCourseId() + "\t" +
                score.getScore() + "\t" +
                score.getExamStatus() + "\t" +
                score.getExamCount()
            );
        }
        
        System.out.println("\n测试完成，共获取到 " + scoreService.getAllScores().size() + " 条成绩数据");
    }
}